"""رمزون — قواعد تسوية الطلبات والكوبونات بعد نتيجة المزود الفعلية.

لا تُعاد قيمة كوبون محجوز عند مجرد ضغط زر الإلغاء، بل فقط بعد
تأكيد الإلغاء/انتهاء المهلة من واجهة المزود وعدم وجود أي رسالة.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _voucher(store: dict, code: str | None) -> dict | None:
    if not code:
        return None
    return next((v for v in store["vouchers"] if v.get("code") == code), None)


def _sms_key(sms: dict) -> str:
    if sms.get("external_key"):
        return str(sms["external_key"])
    if sms.get("sim5_id") is not None:
        return "id:" + str(sms["sim5_id"])
    if sms.get("id") is not None and "order_id" not in sms:
        return "id:" + str(sms["id"])
    record = [sms.get("date") or sms.get("created_at"), sms.get("sender"), sms.get("text"), sms.get("code")]
    return "hash:" + hashlib.sha256(json.dumps(record, ensure_ascii=False, default=str).encode()).hexdigest()


def _transaction(store: dict, order: dict, kind: str, amount: float, customer: dict, description: str) -> None:
    store["transactions"].append({
        "id": max((int(t.get("id", 0)) for t in store["transactions"]), default=0) + 1,
        "customer_id": order["customer_id"],
        "type": kind,
        "description": description,
        "amount": round(amount, 4),
        "balance_after": round(float(customer.get("balance", 0)), 4),
        "created_at": utcnow(),
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "order_id": order["id"],
    })


def settle_sms(store: dict, order: dict, customer: dict, incoming: list[dict]) -> int:
    """يحفظ عدة رسائل دون تكرار، ويستهلك الكوبون مرة واحدة عند وصول أول SMS."""
    order_id = order["id"]
    existing = {_sms_key(s) for s in store["sms"] if s.get("order_id") == order_id}
    new_count = 0
    for sms in incoming:
        if not isinstance(sms, dict):
            continue
        key = _sms_key(sms)
        if key in existing:
            continue
        existing.add(key)
        record = {
            "id": max((int(s.get("id", 0)) for s in store["sms"]), default=0) + 1,
            "external_key": key, "sim5_id": sms.get("id"),
            "customer_id": customer["id"], "order_id": order_id,
            "phone": order.get("phone", ""),
            "sender": sms.get("sender", ""), "text": sms.get("text", ""),
            "code": sms.get("code", ""),
            "created_at": sms.get("date") or sms.get("created_at") or utcnow(),
            "read": False,
        }
        store["sms"].append(record)
        new_count += 1

    complete = [s for s in store["sms"] if s.get("order_id") == order_id]
    order["sms"] = [{
        "id": s.get("sim5_id"), "code": s.get("code"),
        "text": s.get("text"), "sender": s.get("sender"),
        "date": s.get("created_at"),
    } for s in complete]
    if complete and order.get("voucher_reserved") and not order.get("voucher_settled"):
        voucher = _voucher(store, order.get("paid_by_voucher"))
        if voucher and voucher.get("reserved_order_id") == order_id and voucher.get("status") == "reserved":
            voucher.update({
                "status": "used", "used_by": customer["id"],
                "used_at": utcnow(),
                "used_on": {"country": order.get("country_slug"), "service": order.get("service_id")},
            })
            voucher.pop("reserved_order_id", None)
            remainder = round(float(voucher.get("value", 0)) - float(order.get("price", 0)), 4)
            if remainder > 0:
                customer["balance"] = round(float(customer.get("balance", 0)) + remainder, 4)
                _transaction(store, order, "voucher_remainder", remainder, customer, "متبقي الكوبون بعد وصول SMS")
            order["voucher_settled"] = True
        else:
            order["voucher_review_required"] = True
    return new_count


def refund_confirmed_failure(store: dict, order: dict, customer: dict) -> dict:
    """تسوية فشل مؤكد. لا تُرد قيمة إذا وصلت أي رسالة أو تم ردّها سابقًا."""
    if order.get("refunded"):
        return {"refund": 0.0, "voucher_reactivated": False}
    if order.get("sms") or any(s.get("order_id") == order["id"] for s in store["sms"]):
        return {"refund": 0.0, "voucher_reactivated": False}
    if order.get("status") not in {"CANCELED", "CANCELLED", "TIMEOUT"}:
        return {"refund": 0.0, "voucher_reactivated": False}

    amount = round(float(order.get("price", 0)), 4)
    voucher_reactivated = False
    if order.get("paid_by_voucher") and order.get("voucher_reserved"):
        voucher = _voucher(store, order.get("paid_by_voucher"))
        if voucher and voucher.get("reserved_order_id") == order["id"] and voucher.get("status") == "reserved":
            voucher.update({"status": "unused", "last_result": "sms_not_received", "last_attempt_at": utcnow()})
            for field in ("reserved_order_id", "reserved_at", "used_by", "used_at", "used_on"):
                voucher.pop(field, None)
            voucher_reactivated = True
            order["refunded_as"] = "voucher_reactivated"
            _transaction(store, order, "voucher_reactivated", 0, customer, "لم تصل SMS — أعيد الكوبون للاستخدام")
        else:
            order["refunded_as"] = "manual_review_required"
            return {"refund": 0.0, "voucher_reactivated": False, "review_required": True}
    elif not order.get("paid_by_voucher"):
        customer["balance"] = round(float(customer.get("balance", 0)) + amount, 4)
        order["refunded_as"] = "balance"
        _transaction(store, order, "refund", amount, customer, "استرداد طلب لم تصله SMS")
    else:
        # طلب قديم: لا نُفعّل الكوبون لأن النظام السابق كان يضيف استرداده للرصيد.
        order["refunded_as"] = "legacy_review_required"
        return {"refund": 0.0, "voucher_reactivated": False, "review_required": True}

    order["refunded"] = True
    wallet = store.get("owner_wallet", {})
    wallet["total_profit"] = round(float(wallet.get("total_profit", 0)) - float(order.get("profit", 0)), 4)
    wallet["reserved_for_5sim"] = round(float(wallet.get("reserved_for_5sim", 0)) - float(order.get("fivesim_cost", 0)), 4)
    for n in store["numbers"]:
        if n.get("sim5_id") == order.get("sim5_id"):
            n["status"] = "cancelled" if order["status"] != "TIMEOUT" else "expired"
    return {"refund": amount if order.get("refunded_as") == "balance" else 0.0,
            "voucher_reactivated": voucher_reactivated}
