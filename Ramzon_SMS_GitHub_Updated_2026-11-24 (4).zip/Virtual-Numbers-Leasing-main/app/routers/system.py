"""مسارات النظام: /health, /status, /api/v1/system/*."""
from __future__ import annotations

import asyncio
import json
import time

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from sse_starlette.sse import EventSourceResponse

from app.config import (
    HIDE_PRICES_FROM_CUSTOMERS,
    GUEST_MODE,
    GUEST_REQUIRES_VOUCHER,
    HIDE_BALANCE_FROM_CUSTOMERS,
    BLOCKED_COUNTRY_SLUGS,
    BLOCKED_COUNTRY_CODES,
    SIM5_ENABLED,
    FIVESIM_MARKUP_PERCENT,
    ADMIN_SECRET,
)
from app.core.storage import STORE, refresh, store_file_info
from app.core.state import START_TIME, fmt_uptime, now_iso, _REQUEST_STATS
from app.core.keepalive import KA_STATE, add_subscriber, remove_subscriber
from app.services.sim5 import sim5_get, Sim5Error


router = APIRouter()


# ══════════════════════════════════════════════════════════════
# /health
# ══════════════════════════════════════════════════════════════
@router.get("/health")
async def health():
    """Public liveness only; never expose supplier balances or database details."""
    return {"status": "ok", "timestamp": now_iso()}


# ══════════════════════════════════════════════════════════════
# /api/v1/system/health-check
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/health-check")
async def health_check():
    from app.main import app
    return {
        "status": "healthy",
        "version": app.version,
        "uptime": fmt_uptime(time.time() - START_TIME),
        "timestamp": now_iso(),
    }


# ══════════════════════════════════════════════════════════════
# /api/v1/system/version
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/version")
async def system_version():
    """Public capabilities; supplier/account information remains private."""
    from app.main import app
    return {"version": app.version, "name": "Ramzon SMS", "status": "ok"}


# ══════════════════════════════════════════════════════════════
# /api/v1/system/sim5-profile
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/sim5-profile")
async def sim5_profile(request: Request):
    """Legacy endpoint: protect it even if links in old templates still exist."""
    import secrets
    if not ADMIN_SECRET or not secrets.compare_digest(request.headers.get("X-Admin-Secret", ""), ADMIN_SECRET):
        raise HTTPException(403, "غير مصرح")
    if not SIM5_ENABLED:
        raise HTTPException(503, "خدمة الربط غير مفعلة")
    try:
        p = await sim5_get("/user/profile", auth=True)
    except Sim5Error:
        raise HTTPException(503, "خدمة الربط غير متاحة حاليًا")
    return {"ok": True, "balance": p.get("balance"), "frozen_balance": p.get("frozen_balance")}


# ══════════════════════════════════════════════════════════════
# /api/v1/system/whoami
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/whoami")
async def whoami(request: Request):
    refresh()
    if GUEST_MODE:
        return {
            "has_session": False,
            "customer_id": None,
            "customer_in_store": False,
            "email": None,
            "name": "زائر",
            "customers_count": len(STORE["customers"]),
            "guest_mode": True,
        }
    cid = request.session.get("customer_id")
    customer_exists = cid in STORE["customers"] if cid else False
    return {
        "has_session": bool(request.session),
        "customer_id": cid,
        "customer_in_store": customer_exists,
        "email": request.session.get("email"),
        "name": request.session.get("name"),
        "customers_count": len(STORE["customers"]),
    }


# ══════════════════════════════════════════════════════════════
# /api/v1/system/request-stats
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/request-stats")
async def request_stats():
    return _REQUEST_STATS


# ══════════════════════════════════════════════════════════════
# /status
# ══════════════════════════════════════════════════════════════
@router.get("/status", response_class=HTMLResponse)
async def status_page():
    return HTMLResponse("""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>حالة الخدمة — رمزون SMS</title><style>body{font:18px system-ui;background:#121b2b;color:#fafafa;text-align:center;padding:4rem}</style></head><body><h1>رمزون SMS</h1><p>الخدمة قيد التشغيل</p></body></html>""")


# ══════════════════════════════════════════════════════════════
# /api/v1/system/keepalive-status
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/keepalive-status")
async def keepalive_status():
    from app.config import KA_INTERVAL
    elapsed = int(time.time() - START_TIME)
    KA_STATE["uptime"] = fmt_uptime(elapsed)
    KA_STATE["next_ping_in"] = max(0, KA_INTERVAL - (elapsed % KA_INTERVAL))
    return JSONResponse(KA_STATE)


# ══════════════════════════════════════════════════════════════
# /api/v1/system/events (SSE)
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/system/events")
async def sse_events(request: Request):
    queue: asyncio.Queue = asyncio.Queue(maxsize=100)
    add_subscriber(queue)

    async def event_generator():
        elapsed = int(time.time() - START_TIME)
        KA_STATE["uptime"] = fmt_uptime(elapsed)
        yield {"event": "status", "data": json.dumps(KA_STATE, default=str)}

        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    payload = await asyncio.wait_for(queue.get(), timeout=15.0)
                    yield payload
                except asyncio.TimeoutError:
                    yield {"event": "heartbeat", "data": str(int(time.time()))}
        finally:
            remove_subscriber(queue)

    return EventSourceResponse(event_generator())
