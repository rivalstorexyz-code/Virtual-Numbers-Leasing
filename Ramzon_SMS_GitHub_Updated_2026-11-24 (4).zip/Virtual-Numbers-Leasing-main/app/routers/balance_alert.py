"""تنبيه الرصيد المنخفض عبر Vercel daily cron (اختياري وآمن)."""
from __future__ import annotations

import asyncio
import os
import secrets
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage

from fastapi import APIRouter, HTTPException, Request

from app.core.storage import STORE, persist_now, refresh
from app.services.sim5 import sim5_get, Sim5Error

router = APIRouter()


def _send_notification(email: str, balance_sar: float, threshold_sar: float) -> None:
    host = os.environ["SMTP_HOST"]
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.environ["SMTP_USER"]
    password = os.environ["SMTP_PASSWORD"]
    sender = os.environ["SMTP_FROM"]
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = email
    msg["Subject"] = "رمزون SMS — تنبيه انخفاض رصيد المورّد"
    msg.set_content(f"رصيد حساب الأرقام حاليًا {balance_sar:.2f} ريال، أقل من حد التنبيه {threshold_sar:.2f} ريال.\nيرجى شحن الرصيد حتى لا تتوقف الطلبات.")
    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            smtp.login(user, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)


@router.get("/api/internal/low-balance-check")
async def low_balance_check(request: Request):
    token = os.getenv("CRON_SECRET", "")
    if not token or not secrets.compare_digest(request.headers.get("Authorization", ""), "Bearer " + token):
        raise HTTPException(401, "غير مصرح")
    refresh()
    cfg = STORE.get("admin_settings", {})
    rate = float(cfg.get("usd_sar_rate", 3.95))
    threshold = float(cfg.get("low_balance_threshold_sar", 10))
    email = str(cfg.get("alert_email", "rivalstore.xyz@gmail.com"))
    try:
        profile = await sim5_get("/user/profile", auth=True)
        balance = float(profile["balance"]) * rate
    except (Sim5Error, ValueError, KeyError) as exc:
        raise HTTPException(503, "لا يمكن فحص الرصيد") from exc
    if balance > threshold:
        return {"ok": True, "low": False, "email_sent": False}

    smtp_envs = ("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM")
    if not all(os.getenv(k) for k in smtp_envs):
        return {"ok": True, "low": True, "email_sent": False, "reason": "SMTP_NOT_CONFIGURED"}

    # مرة يوميًا كحد أقصى مع منع الإرسال المكرر في حالة إعادة محاولة الجدولة.
    date = datetime.now(timezone.utc).date().isoformat()
    meta = STORE.setdefault("admin_alert_state", {})
    if meta.get("last_email_date") == date:
        return {"ok": True, "low": True, "email_sent": False, "reason": "ALREADY_SENT"}
    try:
        await asyncio.to_thread(_send_notification, email, balance, threshold)
    except Exception as exc:
        raise HTTPException(503, "تعذر إرسال التنبيه؛ تحقق من إعدادات البريد") from exc
    meta["last_email_date"] = date
    persist_now()
    return {"ok": True, "low": True, "email_sent": True}
