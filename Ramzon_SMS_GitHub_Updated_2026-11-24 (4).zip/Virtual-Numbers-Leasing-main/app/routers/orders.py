"""الطلبات: إنشاء، مزامنة، فحص، إنهاء، إلغاء."""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

from app.config import (
    SIM5_ENABLED,
    GUEST_MODE,
    GUEST_REQUIRES_VOUCHER,
    HIDE_PRICES_FROM_CUSTOMERS,
    HIDE_BALANCE_FROM_CUSTOMERS,
)
from app.core.storage import STORE, persist_now, refresh
from app.core.state import now_iso
from app.deps import get_current_customer
from app.models.schemas import OrderCreate
from app.services.sim5 import (
    sim5_get,
    Sim5Error,
    build_live_catalog,
    calculate_sale_price,
    is_country_blocked,
)
from app.services.vouchers import validate_voucher, voucher_allows
from app.services.order_lifecycle import settle_sms, refund_confirmed_failure


router = APIRouter()


# الحالات التي تُعتبر "مغلقة" — لا يجوز إلغاؤها أو إنهاؤها مرة أخرى
# 🔒 إصلاح: ثوابت مركزية لمنع الاسترداد المزدوج
CLOSED_STATUSES = frozenset({"CANCELED", "CANCELLED", "FINISHED", "REFUNDED", "TIMEOUT", "BANNED"})


def _next_id(items: list[dict]) -> int:
    """
    🔒 إصلاح: توليد ID آمن بدل len()+1.
    len()+1 يعطي IDs مكررة بعد أي حذف أو عند التزامن.
    """
    return (max((i["id"] for i in items), default=0)) + 1


def _find_customer_order(customer_id: int, order_id: int) -> dict | None:
    """🔒 إصلاح: مساعد موحّد لتقليل التكرار في check/finish/cancel."""
    return next(
        (o for o in STORE["orders"]
         if o["id"] == order_id and o["customer_id"] == customer_id),
        None,
    )


def _ensure_order_open(order: dict) -> None:
    """
    🔒 إصلاح: يرفض العملية على طلب مغلق.
    يمنع الاسترداد المزدوج عند تكرار الإلغاء أو إلغاء طلب منتهٍ.
    """
    if order.get("status") in CLOSED_STATUSES:
        raise HTTPException(
            400,
            f"الطلب مغلق بالفعل (الحالة: {order['status']}) — لا يمكن تنفيذ العملية",
        )


@router.get("/api/v1/orders/my-active")
async def my_active_orders(request: Request):
    """Only orders belonging to this authenticated visitor session."""
    refresh()
    customer = await get_current_customer(request)
    cid = customer["id"]
    active = [o for o in STORE["orders"] if o.get("customer_id") == cid
              and o.get("status") not in CLOSED_STATUSES]
    active.sort(key=lambda o: str(o.get("created_at", "")), reverse=True)
    return {"orders": [{"id": o.get("id"), "phone": o.get("phone"),
                         "service": o.get("service"), "status": o.get("status"),
                         "created_at": o.get("created_at"), "expires": o.get("expires")}
                        for o in active[:20]]}


# ══════════════════════════════════════════════════════════════
# POST /api/v1/orders
# ══════════════════════════════════════════════════════════════
@router.post("/api/v1/orders")
async def create_order(payload: OrderCreate, request: Request):
    refresh()
    customer = await get_current_customer(request)
    cid = customer["id"]

    if not SIM5_ENABLED:
        raise HTTPException(503, "خدمة الأرقام غير متاحة حاليًا")

    if GUEST_MODE and GUEST_REQUIRES_VOUCHER and not payload.voucher_code:
        raise HTTPException(400, "أدخل كود الشراء أولاً")

    # 🔒 إصلاح: حذف الفحص المكرر لـ is_country_blocked
    # كان يُستدعى قبل وبعد build_live_catalog — واحد يكفي
    if is_country_blocked(payload.country):
        raise HTTPException(400, "هذه الدولة غير متاحة")

    voucher = None
    if payload.voucher_code:
        voucher = validate_voucher(payload.voucher_code)
        if not voucher_allows(voucher, payload.country.lower(), payload.service):
            pairs_str = ", ".join(
                f"{p['country']}/{p['service']}"
                for p in voucher["allowed_pairs"]
            )
            raise HTTPException(
                403,
                f"هذا الكود لا يصلح لـ {payload.country}/{payload.service}. "
                f"يصلح لـ: {pairs_str}",
            )

    result = await build_live_catalog()
    if not result["ok"]:
        raise HTTPException(503, "تعذّر تحميل توفر الأرقام، حاول لاحقًا")

    c_slug = payload.country.lower()

    country = next(
        (c for c in result["countries"]
         if c["slug"] == c_slug or c["code"].lower() == c_slug),
        None,
    )
    if not country:
        raise HTTPException(400, "الدولة غير متاحة")

    service = next(
        (s for s in country["services"]
         if s["id"] == payload.service and s["available"]),
        None,
    )
    if not service:
        raise HTTPException(400, "خدمة غير متوفرة في هذه الدولة")

    if not service.get("operator"):
        raise HTTPException(400, "لم يُحدد مشغل متاح لهذه الخدمة")

    # 🔒 إصلاح: حساب sale_price المتوقع قبل الشراء
    # الكود القديم كان يشتري ثم يكتشف أن sale_price > balance فيضطر للإلغاء.
    # الآن نرفض مبكراً إن كان المتاح لا يغطي السعر النهائي المتوقع.
    expected_cost = float(service.get("fivesim_cost") or service["cost"])
    expected_sale_price = calculate_sale_price(expected_cost)

    if voucher:
        available_balance = voucher["value"]
        source_name = "الكود"
    else:
        if HIDE_BALANCE_FROM_CUSTOMERS and GUEST_MODE:
            raise HTTPException(400, "أدخل كود الشراء أولاً")
        available_balance = customer["balance"]
        source_name = "رصيدك"

    if available_balance < expected_sale_price:
        rate = float(STORE.get("admin_settings", {}).get("usd_sar_rate", 3.95))
        raise HTTPException(
            400,
            f"{source_name} غير كافٍ. المطلوب: {expected_sale_price * rate:.2f} ر.س، "
            f"المتاح: {available_balance * rate:.2f} ر.س",
        )

    try:
        sim5_order = await sim5_get(
            f"/user/buy/activation/{country['slug']}/{service['operator']}/{service['id']}",
            auth=True,
            timeout=30.0,
        )
    except Sim5Error as e:
        raise HTTPException(
            status_code=400 if 400 <= e.status < 500 else 503,
            detail="تعذّر شراء الرقم. حاول بعد قليل" if "wait time" not in e.message.lower() else "يجب الانتظار قليلًا قبل إعادة المحاولة",
        )

    fivesim_cost = float(sim5_order.get("price", expected_cost))
    sale_price = calculate_sale_price(fivesim_cost)
    profit = round(sale_price - fivesim_cost, 4)

    # 🔒 إصلاح: فحص ما بعد الشراء يبقى كشبكة أمان
    # (السعر الفعلي من 5SIM قد يختلف عن المتوقع)
    if voucher:
        if voucher["value"] < sale_price:
            try:
                await sim5_get(f"/user/cancel/{sim5_order['id']}", auth=True)
            except Exception:
                pass
            raise HTTPException(
                400,
                f"قيمة الكود غير كافية. المطلوب: {sale_price * float(STORE.get('admin_settings', {}).get('usd_sar_rate', 3.95)):.2f} ر.س، "
                f"قيمة الكود: {float(voucher['value']) * float(STORE.get('admin_settings', {}).get('usd_sar_rate', 3.95)):.2f} ر.س",
            )
    else:
        if customer["balance"] < sale_price:
            try:
                await sim5_get(f"/user/cancel/{sim5_order['id']}", auth=True)
            except Exception:
                pass
            raise HTTPException(
                400,
                f"رصيدك غير كافٍ. المطلوب: {sale_price * float(STORE.get('admin_settings', {}).get('usd_sar_rate', 3.95)):.2f} ر.س، "
                f"المتاح: {float(customer['balance']) * float(STORE.get('admin_settings', {}).get('usd_sar_rate', 3.95)):.2f} ر.س",
            )

    now = datetime.now(timezone.utc)
    order_id = _next_id(STORE["orders"])

    order = {
        "id": order_id,
        "customer_id": cid,
        "sim5_id": sim5_order.get("id"),
        "phone": sim5_order.get("phone", ""),
        "country": country["name"],
        "country_slug": country["slug"],
        "country_code": country["code"],
        "country_prefix": country.get("prefix", ""),
        "flag": country["flag"],
        "service": service["name"],
        "service_id": service["id"],
        "operator": sim5_order.get("operator", service["operator"]),
        "price": sale_price,
        "fivesim_cost": fivesim_cost,
        "profit": profit,
        "status": sim5_order.get("status", "PENDING"),
        "expires": sim5_order.get("expires"),
        "created_at": sim5_order.get("created_at", now.isoformat()),
        "sms": sim5_order.get("sms") or [],
        "paid_by_voucher": voucher["code"] if voucher else None,
        "refunded": False,  # 🔒 إصلاح: علم صريح لمنع الاسترداد المزدوج
        "voucher_reserved": bool(voucher),
        "voucher_settled": False,
    }
    STORE["orders"].append(order)

    STORE["numbers"].append({
        "id": _next_id(STORE["numbers"]),
        "customer_id": cid,
        "sim5_id": sim5_order.get("id"),
        "phone": order["phone"],
        "country": country["name"],
        "country_code": country["code"],
        "country_prefix": country.get("prefix", ""),
        "flag": country["flag"],
        "service": service["name"],
        "service_id": service["id"],
        "status": "active" if order["status"] in ("PENDING", "RECEIVED") else order["status"],
        "price": sale_price,
        "sms_count": 0,
        "expires": order["expires"],
        "created_at": order["created_at"],
    })

    if voucher:
        # لا نستهلك الكوبون ولا نمنح الباقي حتى يصل أول SMS حقيقي.
        voucher["status"] = "reserved"
        voucher["reserved_order_id"] = order_id
        voucher["reserved_at"] = now.isoformat()
        voucher["last_result"] = "waiting_for_sms"
    else:
        customer["balance"] -= sale_price

    ow = STORE["owner_wallet"]
    ow["total_profit"] += profit
    ow["reserved_for_5sim"] += fivesim_cost

    STORE["transactions"].append({
        "id": _next_id(STORE["transactions"]),
        "customer_id": cid,
        "type": "purchase",
        "description": f"شراء رقم {service['name']} — {country['name']}"
                       + (f" (كود {voucher['code']})" if voucher else ""),
        "amount": -sale_price,
        "balance_after": customer["balance"],
        "created_at": now.isoformat(),
        "date": now.strftime("%Y-%m-%d %H:%M"),
    })

    persist_now()

    response = {
        "id": order_id,
        "phone": order["phone"],
        "status": order["status"],
        "expires": order["expires"],
        "created_at": order["created_at"],
        "service": service["name"],
        "service_id": service["id"],
        "country": country["name"],
        "country_code": country["code"],
        "country_prefix": country.get("prefix", ""),
        "flag": country["flag"],
        "paid_by_voucher": voucher["code"] if voucher else None,
    }
    if not HIDE_PRICES_FROM_CUSTOMERS:
        response["price"] = sale_price
    if not HIDE_BALANCE_FROM_CUSTOMERS:
        response["new_balance"] = customer["balance"]

    return response


# ══════════════════════════════════════════════════════════════
# GET /api/v1/orders/sync
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/orders/sync")
async def sync_orders_from_sim5(request: Request):
    # Importing all supplier orders into the requesting customer's account is unsafe.
    raise HTTPException(403, "مزامنة طلبات المورّد ليست متاحة للزوار")


# ══════════════════════════════════════════════════════════════
# GET /api/v1/orders/{order_id}/check
# ══════════════════════════════════════════════════════════════
@router.get("/api/v1/orders/{order_id}/check")
async def check_order(order_id: int, request: Request):
    refresh()
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    if not order or not order.get("sim5_id"):
        raise HTTPException(404, "الطلب غير موجود")

    try:
        data = await sim5_get(f"/user/check/{order['sim5_id']}", auth=True, timeout=15.0)
    except Sim5Error as e:
        raise HTTPException(429 if "wait time" in e.message.lower() else 503, "يرجى الانتظار قبل إعادة المحاولة" if "wait time" in e.message.lower() else "تعذّر إجراء العملية؛ حاول مجددًا")

    order["status"] = data.get("status", order["status"])
    order["expires"] = data.get("expires", order.get("expires"))

    imported = settle_sms(STORE, order, customer, data.get("sms") or [])
    # RECEIVED تعني انتظار SMS وليس إثبات وصولها.
    if order.get("status") in {"CANCELED", "TIMEOUT"} and not order.get("sms"):
        refund_confirmed_failure(STORE, order, customer)

    for n in STORE["numbers"]:
        if n.get("sim5_id") == order["sim5_id"]:
            n["sms_count"] = len([s for s in STORE["sms"] if s.get("order_id") == order_id])
            if order["status"] == "RECEIVED":
                n["status"] = "active"

    persist_now()

    return {
        "ok": True,
        "status": order["status"],
        "expires": order["expires"],
        "new_sms": imported,
        "sms": order.get("sms") or [],
        "created_at": order.get("created_at"),
        "phone": order.get("phone"),
        "country": order.get("country"), "country_code": order.get("country_code"),
        "service": order.get("service"),
        "service_id": order.get("service_id"),
        "country_prefix": order.get("country_prefix"),
        "refunded": order.get("refunded", False),
    }


# ══════════════════════════════════════════════════════════════
# POST /api/v1/orders/{order_id}/finish
# ══════════════════════════════════════════════════════════════
@router.post("/api/v1/orders/{order_id}/finish")
async def finish_order(order_id: int, request: Request):
    refresh()
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    if not order or not order.get("sim5_id"):
        raise HTTPException(404, "الطلب غير موجود")

    # 🔒 إصلاح: منع إنهاء طلب مغلق مسبقاً
    _ensure_order_open(order)
    if not order.get("sms"):
        raise HTTPException(400, "لا يمكن إنهاء الرقم قبل وصول SMS")

    try:
        data = await sim5_get(f"/user/finish/{order['sim5_id']}", auth=True)
    except Sim5Error as e:
        raise HTTPException(429 if "wait time" in e.message.lower() else 503, "يرجى الانتظار قبل إعادة المحاولة" if "wait time" in e.message.lower() else "تعذّر إجراء العملية؛ حاول مجددًا")

    order["status"] = data.get("status", "FINISHED")
    persist_now()
    return {"ok": True, "status": order["status"]}


# ══════════════════════════════════════════════════════════════
# POST /api/v1/orders/{order_id}/cancel
# ══════════════════════════════════════════════════════════════
@router.post("/api/v1/orders/{order_id}/cancel")
async def cancel_order(order_id: int, request: Request):
    refresh()
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    if not order or not order.get("sim5_id"):
        raise HTTPException(404, "الطلب غير موجود")

    # نتحقق من وصول SMS بالفعل قبل محاولة الإلغاء.
    await check_order(order_id, request)
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    _ensure_order_open(order)
    if order.get("sms"):
        raise HTTPException(409, "وصلت رسالة SMS؛ لا يمكن الإلغاء بعد الاستلام")

    try:
        data = await sim5_get(f"/user/cancel/{order['sim5_id']}", auth=True)
    except Sim5Error as e:
        raise HTTPException(429 if "wait time" in e.message.lower() else 503, "يرجى الانتظار قبل إعادة المحاولة" if "wait time" in e.message.lower() else "تعذّر إجراء العملية؛ حاول مجددًا")

    order["status"] = data.get("status", "CANCELED")

    if order["status"] not in {"CANCELED", "CANCELLED", "TIMEOUT"}:
        persist_now()
        raise HTTPException(409, "لم يؤكد مزود الخدمة الإلغاء بعد؛ لم يتغير الكوبون")
    outcome = refund_confirmed_failure(STORE, order, customer)
    persist_now()
    return {"ok": True, "status": order["status"], **outcome}


@router.get("/api/v1/orders/{order_id}/sms")
async def get_order_sms(order_id: int, request: Request):
    """استعلام SMS للطلب المملوك للجلسة الحالية؛ لا يكشف المفتاح أو المورّد."""
    return await check_order(order_id, request)


@router.post("/api/v1/orders/{order_id}/ban")
async def ban_order(order_id: int, request: Request):
    refresh()
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    if not order or not order.get("sim5_id"):
        raise HTTPException(404, "الطلب غير موجود")
    _ensure_order_open(order)
    # نحدّث حالة الرسائل قبل السماح بالحظر.
    await check_order(order_id, request)
    customer = await get_current_customer(request)
    order = _find_customer_order(customer["id"], order_id)
    _ensure_order_open(order)
    if order.get("sms") or any(s.get("order_id") == order_id for s in STORE["sms"]):
        raise HTTPException(400, "لا يمكن حظر الرقم بعد وصول SMS")
    try:
        data = await sim5_get(f"/user/ban/{order['sim5_id']}", auth=True)
    except Sim5Error as e:
        if "wait time" in e.message.lower():
            raise HTTPException(429, "يرجى الانتظار قبل إعادة المحاولة")
        raise HTTPException(409, "تعذّر حظر الرقم حاليًا؛ تحقق من حالة الطلب")
    order["status"] = data.get("status", "BANNED")
    persist_now()
    return {"ok": True, "status": order["status"], "refund": 0,
            "message": "الحظر لا يعني ضمان استرداد المبلغ أو إعادة الكوبون"}
