"""المحفظة: استرداد كود + طلب إيداع."""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

from app.config import GUEST_MODE
from app.core.storage import STORE, persist_now, refresh
from app.core.state import now_iso
from app.deps import get_current_customer
from app.models.schemas import VoucherRedeem, DepositRequestCreate
from app.services.sim5 import is_country_blocked
from app.services.vouchers import validate_voucher, voucher_allows


router = APIRouter()


@router.post("/api/v1/wallet/redeem-voucher")
async def redeem_voucher(payload: VoucherRedeem, request: Request):
    # A voucher represents a single SMS purchase. Converting it to generic wallet
    # credit would consume it before SMS and bypass allowed country/service pairs.
    raise HTTPException(
        409,
        "استخدم الكوبون في صفحة شراء الرقم. لا يتم استهلاكه قبل وصول SMS.",
    )


@router.post("/api/v1/wallet/deposit-request")
async def create_deposit_request(payload: DepositRequestCreate, request: Request):
    refresh()
    if GUEST_MODE:
        raise HTTPException(403, "طلبات الإيداع غير متاحة في وضع الزائر")
    customer = await get_current_customer(request)

    deposit = {
        "id": len(STORE["deposits"]) + 1,
        "customer_id": customer["id"],
        "amount": payload.amount,
        "method": payload.method,
        "reference": payload.reference,
        "status": "pending",
        "created_at": now_iso(),
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "reviewed_at": None,
    }
    STORE["deposits"].append(deposit)
    persist_now()

    return {
        "status": "pending",
        "request_id": deposit["id"],
        "message": "طلبك قيد المراجعة",
    }
