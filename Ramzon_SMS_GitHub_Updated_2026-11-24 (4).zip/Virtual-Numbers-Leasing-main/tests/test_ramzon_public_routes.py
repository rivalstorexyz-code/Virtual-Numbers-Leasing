"""Offline customer route/security checks with fake storage; no supplier spend."""
import copy
import importlib
import os
import sys
import types

from fastapi.testclient import TestClient


def test_customer_data_isolation_and_admin_secret(monkeypatch):
    monkeypatch.setenv('SECRET_KEY', 'TEST_ONLY_COOKIE_SECRET')
    monkeypatch.setenv('ADMIN_SECRET', 'TEST_ONLY_ADMIN_SECRET')
    monkeypatch.setenv('GUEST_MODE', 'true')
    monkeypatch.setenv('SESSION_COOKIE_SECURE', 'false')
    db = {'customers': {}, 'numbers': [], 'orders': [], 'sms': [], 'transactions': [],
          'deposits': [], 'tickets': [], 'sessions': [], 'vouchers': [], 'access_codes': [],
          'popular_services': [], 'owner_wallet': {'total_profit':0, 'total_revenue':0, 'reserved_for_5sim':0}}
    fake = types.ModuleType('shared_storage')
    fake.load_store = lambda: copy.deepcopy(db)
    fake.reload_from_disk = lambda: copy.deepcopy(db)
    def write(store):
        db.clear(); db.update(copy.deepcopy(store))
    fake.save_now = fake.schedule_save = write
    fake.backup = lambda _: None
    fake.store_status = lambda: {'target': 'TEST_ONLY', 'exists': True, 'backend': 'memory'}
    fake.STORE_FILE = 'TEST_ONLY'
    monkeypatch.setitem(sys.modules, 'shared_storage', fake)
    sse = types.ModuleType('sse_starlette')
    sse_sub = types.ModuleType('sse_starlette.sse')
    from starlette.responses import StreamingResponse
    sse_sub.EventSourceResponse = StreamingResponse
    monkeypatch.setitem(sys.modules, 'sse_starlette', sse)
    monkeypatch.setitem(sys.modules, 'sse_starlette.sse', sse_sub)
    for name in list(sys.modules):
        if name.startswith('app.routers') or name.startswith('app.services.customers') or name.startswith('app.core.storage') or name in {'app.main','admin.main','app.config','app.deps'}:
            sys.modules.pop(name, None)
    mod = importlib.import_module('app.main')
    with TestClient(mod.app) as c1, TestClient(mod.app) as c2:
        assert c1.get('/health').status_code == 200
        assert c1.get('/api/v1/system/sim5-profile').status_code == 403
        assert c1.get('/api/v1/orders/sync').status_code == 403
        assert c1.get('/ops/api/v1/admin/whoami').status_code == 403
        assert c1.get('/ops/api/v1/admin/whoami',headers={'X-Admin-Secret':'TEST_ONLY_ADMIN_SECRET'}).status_code == 200
        x = c1.get('/api/v1/orders/my-active');assert x.status_code==200,x.text
        y = c2.get('/api/v1/orders/my-active');assert y.status_code==200,y.text
        assert len(db['customers']) == 2, list(db['customers'])
        ids = sorted(db['customers'])
        db['orders'].append({'id':100,'customer_id':ids[0],'status':'RECEIVED','phone':'+4400000',
                'service':'whatsapp','created_at':'2026-11-24T12:00:00+00:00', 'expires':'2026-11-24T12:15:00+00:00'})
        assert [o['id'] for o in c1.get('/api/v1/orders/my-active').json()['orders']] == [100]
        assert c2.get('/api/v1/orders/my-active').json()['orders'] == []
        assert c2.get('/api/v1/orders/100/sms').status_code == 404


def test_full_voucher_to_sms_flow_without_real_supplier(monkeypatch):
    """End to end: checking a voucher doesn't spend it; only actual SMS does.

    No network or real database; simulates one supplier purchase followed by two SMS.
    """
    monkeypatch.setenv('SECRET_KEY', 'TEST_ONLY_COOKIE_SECRET')
    monkeypatch.setenv('ADMIN_SECRET', 'TEST_ONLY_ADMIN_SECRET')
    monkeypatch.setenv('GUEST_MODE', 'true')
    monkeypatch.setenv('SESSION_COOKIE_SECURE', 'false')
    monkeypatch.setenv('SIM5_API_KEY', 'TEST_ONLY_FAKE_TOKEN')
    database = {'customers': {}, 'numbers': [], 'orders': [], 'sms': [], 'transactions': [],
                'deposits': [], 'tickets': [], 'sessions': [], 'vouchers': [], 'access_codes': [],
                'popular_services': [], 'owner_wallet': {'total_profit': 0, 'total_revenue': 0, 'reserved_for_5sim': 0}}
    fake = types.ModuleType('shared_storage')
    fake.load_store = lambda: copy.deepcopy(database)
    fake.reload_from_disk = lambda: copy.deepcopy(database)
    def persist(s):
        database.clear()
        database.update(copy.deepcopy(s))
    fake.save_now = fake.schedule_save = persist
    fake.backup = lambda _: None
    fake.store_status = lambda: {'target': 'TEST_ONLY', 'exists': True, 'backend': 'memory'}
    fake.STORE_FILE = 'TEST_ONLY'
    monkeypatch.setitem(sys.modules, 'shared_storage', fake)
    sse = types.ModuleType('sse_starlette')
    sse_sub = types.ModuleType('sse_starlette.sse')
    from starlette.responses import StreamingResponse
    sse_sub.EventSourceResponse = StreamingResponse
    monkeypatch.setitem(sys.modules, 'sse_starlette', sse)
    monkeypatch.setitem(sys.modules, 'sse_starlette.sse', sse_sub)
    for name in list(sys.modules):
        if name.startswith('app.routers') or name.startswith('app.services.customers') or name.startswith('app.services.vouchers') or name.startswith('app.core.storage') or name in {'app.main', 'admin.main', 'app.config', 'app.deps'}:
            sys.modules.pop(name, None)
    app_mod = importlib.import_module('app.main')
    orders = importlib.import_module('app.routers.orders')
    async def catalog(*a, **kw):
        return {'ok': True, 'countries': [{'slug': 'england', 'code': 'GB', 'name': 'England',
            'prefix': '44', 'flag': 'GB', 'services': [{'id': 'whatsapp', 'name':'WhatsApp',
            'available': True, 'operator':'any', 'cost':1, 'fivesim_cost': 1}]}]}
    sms_messages = []
    async def supplier(path, *a, **kw):
        if '/user/buy/activation/' in path:
            return {'id': 778, 'phone': '+447700900001', 'price': 1, 'status': 'RECEIVED',
                    'expires': '2026-11-24T18:00:00Z', 'sms': []}
        if '/user/check/' in path:
            return {'status':'RECEIVED', 'expires':'2026-11-24T18:00:00Z', 'sms':sms_messages}
        raise AssertionError(f'Unexpected supplier call: {path}')
    monkeypatch.setattr(orders, 'build_live_catalog', catalog)
    monkeypatch.setattr(orders, 'sim5_get', supplier)
    with TestClient(app_mod.app) as c:
        database['vouchers'].append({'id':1,'code':'TEST-GUEST', 'value':2.0,
            'status':'unused','allowed_pairs':[], 'created_at':'2026-11-24T12:00:00Z',
            'expires_at':'2027-12-01T00:00:00Z'})
        check = c.post('/api/v1/vouchers/check',json={'code':'TEST-GUEST'})
        assert check.status_code == 200, check.text
        assert database['vouchers'][0]['status'] == 'unused'
        purchase = c.post('/api/v1/orders',json={'country':'england','service':'whatsapp','voucher_code':'TEST-GUEST'})
        assert purchase.status_code == 200,purchase.text
        oid = purchase.json()['id']
        assert database['vouchers'][0]['status'] == 'reserved'
        assert c.post('/api/v1/vouchers/check',json={'code':'TEST-GUEST'}).status_code == 409
        assert c.get(f'/api/v1/orders/{oid}/sms').json()['sms'] == []
        assert database['vouchers'][0]['status'] == 'reserved'
        sms_messages.append({'id':12, 'code':'111111','text':'Your OTP is 111111', 'sender':'WA', 'date':'2026-11-24T13:04:00Z'})
        reply = c.get(f'/api/v1/orders/{oid}/sms')
        assert reply.status_code == 200,reply.text
        assert database['vouchers'][0]['status'] == 'used'
        assert len(reply.json()['sms']) == 1
        sms_messages.append({'id':13, 'code':'222222','text':'رمز التحقق 222222', 'sender':'WA', 'date':'2026-11-24T13:05:00Z'})
        assert len(c.get(f'/api/v1/orders/{oid}/sms').json()['sms']) == 2
        assert c.post(f'/api/v1/orders/{oid}/cancel').status_code == 409
        assert len(database['sms']) == 2
