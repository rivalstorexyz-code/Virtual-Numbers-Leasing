"""No-network admin API smoke: mocked shared storage and supplier profile."""
import copy
import importlib
import os
import sys
import types
import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def admin_ctx(monkeypatch):
    monkeypatch.setenv('ADMIN_SECRET', 'TEST_ONLY_SECRET')
    db = {'customers': {}, 'numbers': [], 'orders': [], 'sms': [],
          'transactions': [], 'deposits': [], 'tickets': [], 'sessions': [],
          'vouchers': [], 'access_codes': [], 'popular_services': [],
          'owner_wallet': {'total_profit': 0., 'total_revenue': 0., 'reserved_for_5sim': 0.}}
    fake = types.ModuleType('shared_storage')
    fake.load_store = lambda: copy.deepcopy(db)
    fake.reload_from_disk = lambda: copy.deepcopy(db)
    def save(store):
        db.clear()
        db.update(copy.deepcopy(store))
    fake.save_now = fake.schedule_save = save
    fake.backup = lambda _: None
    fake.STORE_FILE = 'TEST_ONLY'
    fake.store_status = lambda: {'target': 'TEST_ONLY', 'exists': True, 'backend': 'memory'}
    monkeypatch.setitem(sys.modules, 'shared_storage', fake)
    sys.modules.pop('admin.main', None)
    mod = importlib.import_module('admin.main')
    client = TestClient(mod.app)
    yield mod, client, db
    client.close()
    sys.modules.pop('admin.main', None)


def test_admin_closed_by_default(admin_ctx):
    mod, client, db = admin_ctx
    assert client.get('/api/v1/admin/vouchers').status_code == 403
    assert client.get('/api/v1/admin/wallet').status_code == 403
    assert client.get('/health').status_code == 403
    assert client.get('/api/v1/admin/whoami', headers={'X-Admin-Secret':'bad'}).status_code == 403
    assert client.get('/api/v1/admin/whoami', headers={'X-Admin-Secret':'TEST_ONLY_SECRET'}).status_code == 200


def test_sale_record_not_auto_generated_revenue(admin_ctx):
    mod, client, db = admin_ctx
    db['vouchers'].append({'id': 1, 'code': 'ABC123', 'value': 9, 'status': 'used',
        'used_at': '2026-11-24T13:00:00Z', 'allowed_pairs': [], 'created_at':'2026-11-24T12:00:00Z'})
    h = {'X-Admin-Secret': 'TEST_ONLY_SECRET'}
    before = client.get('/api/v1/admin/analytics?month=2026-11',headers=h)
    assert before.status_code == 200, before.text
    assert before.json()['confirmed_sales_sar'] == 0
    mark = client.post('/api/v1/admin/vouchers/1/sale',headers=h,json={'sold_price_sar': 12.5})
    assert mark.status_code == 200, mark.text
    after = client.get('/api/v1/admin/analytics?month=2026-11',headers=h)
    assert after.json()['confirmed_sales_sar'] == 12.5
    assert client.post('/api/v1/admin/vouchers/1/sale',headers=h,json={'sold_price_sar':99}).status_code == 409


def test_fx_settings_and_real_supplier_balance(admin_ctx, monkeypatch):
    mod, client, db = admin_ctx
    h = {'X-Admin-Secret': 'TEST_ONLY_SECRET'}
    patch = client.put('/api/v1/admin/settings',headers=h,json={
        'usd_sar_rate':3.95,'low_balance_threshold_sar':10,'alert_email':'rivalstore.xyz@gmail.com'})
    assert patch.status_code == 200, patch.text
    async def profile(*args, **kwargs):
        return {'balance': 2.5, 'frozen_balance':0.25}
    monkeypatch.setattr(mod, '_sim5_get', profile)
    wallet = client.get('/api/v1/admin/wallet',headers=h)
    assert wallet.status_code == 200, wallet.text
    assert wallet.json()['balance_sar'] == 9.88
    assert wallet.json()['low_balance'] is True


def test_unsold_listing_value_is_not_revenue(admin_ctx):
    mod, client, db = admin_ctx
    db['vouchers'].append({'id': 7, 'code': 'NOT-SOLD', 'value': 3, 'status':'unused',
        'batch_id':'batch_test', 'allowed_pairs':[], 'created_at':'2026-11-24T13:00:00Z'})
    h={'X-Admin-Secret':'TEST_ONLY_SECRET'}
    first=client.get('/api/v1/admin/vouchers',headers=h)
    assert first.json()['summary']['listed_unused_price_sar'] == 0
    r=client.post('/api/v1/admin/vouchers/7/listed',headers=h,json={'listing_price_sar':15})
    assert r.status_code == 200,r.text
    listed=client.get('/api/v1/admin/vouchers',headers=h).json()['summary']
    assert listed['listed_unused_price_sar'] == 15
    assert listed['verified_sales_sar'] == 0
    analytics=client.get('/api/v1/admin/analytics?month=2026-11',headers=h).json()
    assert analytics['confirmed_sales_sar'] == 0


def test_listing_price_is_not_counted_as_revenue(admin_ctx):
    mod, client, db = admin_ctx
    h = {'X-Admin-Secret': 'TEST_ONLY_SECRET'}
    db['vouchers'].extend([
        {'id':1,'code':'UNUSED-1','value':6.0,'status':'unused','batch_id':'b7',
         'created_at':'2026-11-24T12:00:00Z','expires_at':'2027-01-01T12:00:00Z'},
        {'id':2,'code':'UNUSED-2','value':6.0,'status':'unused','batch_id':'b7',
         'created_at':'2026-11-24T12:00:00Z','expires_at':'2027-01-01T12:00:00Z'},
    ])
    resp = client.post('/api/v1/admin/vouchers/batch/b7/listed',json={'listing_price_sar':15.5},headers=h)
    assert resp.status_code == 200,resp.text
    vouchers = client.get('/api/v1/admin/vouchers?status_filter=unused',headers=h).json()
    assert len(vouchers['vouchers']) == 2
    assert vouchers['summary']['listed_unused_price_sar'] == 31.0
    assert vouchers['summary']['verified_sales_sar'] == 0
    analytics = client.get('/api/v1/admin/analytics?month=2026-11',headers=h).json()
    assert analytics['confirmed_sales_sar'] == 0
    assert analytics['estimated_profit_sar'] == 0
