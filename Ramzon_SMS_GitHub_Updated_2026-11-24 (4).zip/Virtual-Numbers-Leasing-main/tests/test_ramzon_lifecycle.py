"""Offline safety checks: no real supplier requests and no production database access."""
from copy import deepcopy

from app.services.order_lifecycle import settle_sms, refund_confirmed_failure


def sample():
    order = {
        'id': 42, 'customer_id': 3, 'sim5_id': 770, 'phone': '+447700900000',
        'paid_by_voucher': 'TEST-111', 'voucher_reserved': True,
        'voucher_settled': False, 'status': 'RECEIVED', 'price': 4,
        'profit': 1, 'fivesim_cost': 3, 'country_slug': 'england',
        'service_id': 'whatsapp', 'sms': [], 'refunded': False,
    }
    customer = {'id': 3, 'balance': 0}
    voucher = {'code': 'TEST-111', 'value': 5, 'status': 'reserved', 'reserved_order_id': 42}
    store = {
        'sms': [], 'orders': [order], 'numbers': [{'sim5_id': 770, 'status': 'active'}],
        'vouchers': [voucher], 'transactions': [],
        'owner_wallet': {'total_profit': 1, 'reserved_for_5sim': 3},
    }
    return store, order, customer, voucher


def test_validation_is_not_consumption():
    store, order, customer, voucher = sample()
    assert voucher['status'] == 'reserved'
    assert customer['balance'] == 0
    assert not order['voucher_settled']


def test_first_sms_consumes_voucher_then_stores_second():
    store, order, customer, voucher = sample()
    sms1 = {'id': 555, 'code': '111222', 'text': 'Your code 111222', 'sender': 'WA', 'date': '2026-11-24T13:00:00Z'}
    sms2 = {'id': 556, 'code': '333444', 'text': 'رمز التحقق 333444', 'sender': 'WA', 'date': '2026-11-24T13:01:00Z'}
    assert settle_sms(store, order, customer, [sms1]) == 1
    assert voucher['status'] == 'used'
    assert order['voucher_settled'] is True
    assert customer['balance'] == 1
    assert settle_sms(store, order, customer, [sms1, sms2]) == 1
    assert [sms['code'] for sms in order['sms']] == ['111222','333444']
    assert customer['balance'] == 1
    assert len(store['transactions']) == 1


def test_no_double_count_after_polling():
    store, order, customer, voucher = sample()
    msg = {'id': 555, 'code': '111222', 'text': 'Your code 111222', 'sender': 'WA', 'date': '2026-11-24T13:00:00Z'}
    assert settle_sms(store, order, customer, [msg]) == 1
    assert settle_sms(store, order, customer, [msg]) == 0
    assert len(order['sms']) == 1
    assert len(store['sms']) == 1


def test_cancel_without_sms_restores_voucher_once():
    store, order, customer, voucher = sample()
    order['status'] = 'CANCELED'
    out = refund_confirmed_failure(store, order, customer)
    assert out['voucher_reactivated'] is True
    assert voucher['status'] == 'unused'
    assert voucher['last_result'] == 'sms_not_received'
    assert order['refunded'] is True
    assert store['owner_wallet']['total_profit'] == 0
    assert store['owner_wallet']['reserved_for_5sim'] == 0
    assert refund_confirmed_failure(store, order, customer)['voucher_reactivated'] is False
    assert len(store['transactions']) == 1


def test_cannot_refund_if_sms_exists():
    store, order, customer, voucher = sample()
    settle_sms(store, order, customer, [{'id': 55, 'text': '1234', 'code': '1234'}])
    order['status'] = 'CANCELED'
    out = refund_confirmed_failure(store, order, customer)
    assert not out['voucher_reactivated']
    assert voucher['status'] == 'used'
    assert customer['balance'] == 1


def test_no_assumed_success_if_reserved_voucher_is_missing():
    store, order, customer, voucher = sample()
    store['vouchers'] = []
    order['status'] = 'CANCELED'
    out = refund_confirmed_failure(store, order, customer)
    assert out['review_required'] is True
    assert not order['refunded']
    assert store['owner_wallet']['total_profit'] == 1


def test_legacy_voucher_requires_manual_review():
    store, order, customer, voucher = sample()
    order.pop('voucher_reserved')
    order['status'] = 'TIMEOUT'
    result = refund_confirmed_failure(store, order, customer)
    assert result['review_required'] is True
    assert customer['balance'] == 0
