# admin/main.py
"""
Jamal Solutions — Admin Panel (standalone + shared storage)

- GET  /                       → admin.html
- GET  /api/v1/admin/catalog   → دول + خدمات + توفر (منطق app/main.py)
- كل /api/v1/admin/*           → 🔓 مفتوحة (بدون تحقق)

التخزين المشترك (shared_storage.py في جذر المشروع):
    project/data/store.json     (أو DATA_DIR=/var/data على Render Disks)
    project/data/backups/
    أو PostgreSQL عبر DATABASE_URL

التشغيل (من داخل admin/):
    uvicorn main:app --host 127.0.0.1 --port 8001 --workers 1

⚠️  workers=1 لكلا التطبيقين.
⚠️  بدون تسجيل دخول — لا تنشرها على إنترنت عام.

✨ v2.5.1:
    - label (اسم اختياري) لكل دفعة أكواد
    - endpoint /vouchers/used — الأكواد المستخدمة
    - حذف access-codes نهائياً من admin
    - matrix generate مع label
    - ✨ حجب الدول المحظورة (إسرائيل افتراضياً)
"""
from __future__ import annotations

import asyncio
import os
import secrets
import sys
import time
from datetime import datetime, timedelta, timezone
import re
import uuid
from pathlib import Path
from typing import Any, Optional

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field


# ══════════════════════════════════════════════════════════════
# 1) Paths
# ══════════════════════════════════════════════════════════════
ADMIN_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = ADMIN_DIR.parent
TEMPLATES_DIR = ADMIN_DIR / "templates"
STATIC_DIR = ADMIN_DIR / "static"


# ══════════════════════════════════════════════════════════════
# 2) التخزين الدائم المشترك
# ══════════════════════════════════════════════════════════════
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from shared_storage import (  # type: ignore
    load_store,
    schedule_save,
    save_now,
    backup,
    reload_from_disk,
    STORE_FILE,
)

try:
    from shared_storage import store_status as _store_status  # type: ignore
    _HAS_STORE_STATUS = True
except ImportError:
    _store_status = None
    _HAS_STORE_STATUS = False


STORE: dict = load_store()
STORE.setdefault("popular_services", [])
print(f"[admin] 💾 store loaded from {STORE_FILE}")


def _store_file_info() -> dict:
    if _HAS_STORE_STATUS:
        try:
            st = _store_status()
            return {
                "path": st.get("target", str(STORE_FILE)),
                "exists": st.get("exists", True),
                "kind": st.get("backend", "unknown"),
                "version": st.get("version"),
                "size_bytes": st.get("size_bytes"),
            }
        except Exception as e:
            print(f"[admin] ⚠️  store_status فشل: {type(e).__name__}: {e}")

    if isinstance(STORE_FILE, Path):
        return {
            "path": str(STORE_FILE),
            "exists": STORE_FILE.exists(),
            "kind": "file",
        }
    s = str(STORE_FILE)
    is_dsn = ("://" in s) or ("@/" in s)
    return {
        "path": s,
        "exists": True,
        "kind": "dsn" if is_dsn else "string",
    }


def _persist() -> None:
    schedule_save(STORE)


def _persist_now() -> None:
    save_now(STORE)


def _refresh() -> None:
    fresh = reload_from_disk()
    STORE.clear()
    STORE.update(fresh)
    STORE.setdefault("popular_services", [])


# ══════════════════════════════════════════════════════════════
# 3) 5SIM — إعدادات
# ══════════════════════════════════════════════════════════════
SIM5_BASE = os.getenv("SIM5_BASE", "https://5sim.net/v1").rstrip("/")
SIM5_API_KEY = os.getenv("SIM5_API_KEY", "").strip()
SIM5_ENABLED = bool(SIM5_API_KEY)

FIVESIM_MARKUP_PERCENT = float(os.getenv("FIVESIM_MARKUP_PERCENT", "40"))


# ══════════════════════════════════════════════════════════════
# ✨ 3a) دول محظورة (لا تُعرض في لوحة التحكم)
# ══════════════════════════════════════════════════════════════
BLOCKED_COUNTRY_SLUGS = {
    s.strip().lower()
    for s in os.getenv("BLOCKED_COUNTRY_SLUGS", "israel").split(",")
    if s.strip()
}
BLOCKED_COUNTRY_CODES = {
    s.strip().upper()
    for s in os.getenv("BLOCKED_COUNTRY_CODES", "IL").split(",")
    if s.strip()
}


def _is_country_blocked(slug: str, code: str = "") -> bool:
    """هل الدولة محظورة (بالـ slug أو الـ ISO code)؟"""
    if slug and slug.strip().lower() in BLOCKED_COUNTRY_SLUGS:
        return True
    if code and code.strip().upper() in BLOCKED_COUNTRY_CODES:
        return True
    return False


class Sim5Error(Exception):
    def __init__(self, status_code: int, message: str, endpoint: str = ""):
        self.status = status_code
        self.message = message
        self.endpoint = endpoint
        super().__init__(f"[{status_code}] {message} ({endpoint})")


def _sim5_explain_400(text: str) -> str:
    t = text.lower()
    if "no free phones" in t:
        return "لا توجد أرقام متاحة حاليًا لهذه الدولة/الخدمة"
    if "not enough user balance" in t:
        return "رصيد 5SIM غير كافٍ"
    if "bad country" in t:
        return "الدولة غير مدعومة في 5SIM"
    if "bad operator" in t:
        return "المشغل غير مدعوم في 5SIM"
    if "no product" in t:
        return "الخدمة غير مدعومة في 5SIM"
    if "server offline" in t:
        return "خادم 5SIM غير متصل"
    return f"خطأ من 5SIM: {text[:200]}"


async def _sim5_get(path: str, auth: bool = False, timeout: float = 25.0) -> Any:
    if not SIM5_ENABLED and auth:
        raise Sim5Error(503, "5SIM غير مفعّل — SIM5_API_KEY غير مضبوط", path)

    url = f"{SIM5_BASE}{path}"
    headers = {"Accept": "application/json"}
    if auth and SIM5_API_KEY:
        headers["Authorization"] = f"Bearer {SIM5_API_KEY}"

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(url, headers=headers)
    except httpx.TimeoutException:
        raise Sim5Error(0, "انتهت مهلة الاتصال بـ 5SIM", path)
    except httpx.RequestError as e:
        raise Sim5Error(0, f"فشل الاتصال بـ 5SIM: {type(e).__name__}", path)

    if r.status_code == 200:
        try:
            return r.json()
        except Exception:
            raise Sim5Error(200, "استجابة 5SIM ليست JSON صالحًا", path)

    if r.status_code == 400:
        raise Sim5Error(400, _sim5_explain_400(r.text), path)
    if r.status_code == 401:
        raise Sim5Error(401, "مفتاح 5SIM غير صالح أو منتهي", path)
    if r.status_code == 403:
        raise Sim5Error(403, "لا تملك صلاحية لهذا الإجراء في 5SIM", path)
    if r.status_code == 404:
        raise Sim5Error(404, "العنصر غير موجود في 5SIM", path)
    if r.status_code == 429:
        raise Sim5Error(429, "تجاوزت حد الطلبات (100/ثانية) — حاول بعد قليل", path)
    if r.status_code == 503:
        raise Sim5Error(503, "5SIM مشغول حاليًا أو تجاوزت حد الطلبات", path)
    raise Sim5Error(r.status_code, f"استجابة غير متوقعة من 5SIM: {r.text[:200]}", path)


# ══════════════════════════════════════════════════════════════
# 3b) أدوات مساعدة
# ══════════════════════════════════════════════════════════════
def _iso_to_flag(iso: str) -> str:
    if not iso or len(iso) != 2:
        return "🏳️"
    return "".join(chr(0x1F1E6 + ord(c) - ord("A")) for c in iso.upper())


_SERVICE_ICONS = {
    "whatsapp": "💬", "telegram": "✈️", "google": "🔍", "facebook": "📘",
    "twitter": "🐦", "instagram": "📷", "tiktok": "🎵", "amazon": "📦",
    "snapchat": "👻", "discord": "🎮", "uber": "🚕", "netflix": "🎬",
    "apple": "🍎", "microsoft": "🪟", "yahoo": "🟣", "steam": "🎮",
    "binance": "🟡", "coinbase": "🔵", "paypal": "🅿️", "alipay": "🅰️",
    "wechat": "💚", "line": "💚", "viber": "📞", "signal": "🔒",
    "tinder": "❤️", "bumble": "🐝", "clubhouse": "🎙️", "twitch": "🎮",
    "spotify": "🎵", "yandex": "🔴", "vk": "🔵", "ok": "🟠",
    "airbnb": "🏠", "aliexpress": "🛒", "alibaba": "🏭", "ebay": "🛍️",
    "walmart": "🛒", "target": "🎯", "bestbuy": "🛒", "costco": "🛒",
    "openai": "🤖", "chatgpt": "🤖", "claudeai": "🤖", "gemini": "✨",
    "deepseek": "🐋", "perplexity": "🔎", "poeai": "💬",
}


def _service_icon(slug: str) -> str:
    return _SERVICE_ICONS.get(slug.lower(), "📱")


def _calculate_sale_price(fivesim_cost: float) -> float:
    if fivesim_cost <= 0:
        return 0.0
    markup = fivesim_cost * (FIVESIM_MARKUP_PERCENT / 100.0)
    return round(fivesim_cost + markup, 2)


# ══════════════════════════════════════════════════════════════
# 3c) كتالوج 5SIM
# ══════════════════════════════════════════════════════════════
CATALOG_TTL_SECONDS = float(os.getenv("CATALOG_TTL_SECONDS", "300"))
_SIM5_CACHE: dict[str, dict] = {
    "prices": {"data": None, "at": 0.0},
    "countries": {"data": None, "at": 0.0},
}
_SIM5_LOCK = asyncio.Lock()


async def _fetch_sim5_countries(force: bool = False) -> dict:
    now = time.time()
    cached = _SIM5_CACHE["countries"]
    if not force and cached["data"] and (now - cached["at"]) < CATALOG_TTL_SECONDS:
        return cached["data"]
    async with _SIM5_LOCK:
        now = time.time()
        if not force and cached["data"] and (now - cached["at"]) < CATALOG_TTL_SECONDS:
            return cached["data"]
        data = await _sim5_get("/guest/countries", auth=False)
        _SIM5_CACHE["countries"] = {"data": data, "at": time.time()}
        return data


async def _fetch_sim5_prices(force: bool = False) -> dict:
    now = time.time()
    cached = _SIM5_CACHE["prices"]
    if not force and cached["data"] and (now - cached["at"]) < CATALOG_TTL_SECONDS:
        return cached["data"]
    async with _SIM5_LOCK:
        now = time.time()
        if not force and cached["data"] and (now - cached["at"]) < CATALOG_TTL_SECONDS:
            return cached["data"]
        data = await _sim5_get("/guest/prices", auth=False)
        _SIM5_CACHE["prices"] = {"data": data, "at": time.time()}
        return data


async def build_live_catalog(force: bool = False) -> dict:
    if not SIM5_ENABLED:
        return {
            "ok": False,
            "countries": [],
            "error": "SIM5_API_KEY غير مضبوط",
            "error_code": None,
            "fetched_at": None,
        }
    try:
        raw_countries = await _fetch_sim5_countries(force=force)
        raw_prices = await _fetch_sim5_prices(force=force)
    except Sim5Error as e:
        return {
            "ok": False,
            "countries": [],
            "error": e.message,
            "error_code": e.status,
            "fetched_at": None,
        }

    countries_out: list[dict] = []

    for country_slug, cmeta in raw_countries.items():
        iso_raw = cmeta.get("iso") or {}
        iso = next(iter(iso_raw.keys()), "").upper() if isinstance(iso_raw, dict) else ""

        # ✨ تخطّي الدول المحظورة
        if _is_country_blocked(country_slug, iso):
            continue

        prefix_raw = cmeta.get("prefix") or {}
        prefix = next(iter(prefix_raw.keys()), "") if isinstance(prefix_raw, dict) else ""
        name_en = cmeta.get("text_en") or country_slug

        country_prices = raw_prices.get(country_slug) or {}
        services: list[dict] = []

        for product_slug, operators in country_prices.items():
            best = None
            for op_name, info in (operators or {}).items():
                try:
                    cost = float(info.get("cost", 0))
                    count = int(info.get("count", 0))
                    rate = float(info["rate"]) if info.get("rate") else None
                except (TypeError, ValueError):
                    continue
                if count <= 0 or cost <= 0:
                    continue
                if best is None or cost < best["fivesim_cost"]:
                    best = {
                        "fivesim_cost": cost,
                        "cost": _calculate_sale_price(cost),
                        "count": count,
                        "rate": rate,
                        "operator": op_name,
                    }

            services.append({
                "id": product_slug,
                "name": product_slug,
                "icon": _service_icon(product_slug),
                "cost": best["cost"] if best else None,
                "fivesim_cost": best["fivesim_cost"] if best else None,
                "count": best["count"] if best else 0,
                "rate": best["rate"] if best else None,
                "operator": best["operator"] if best else None,
                "available": best is not None,
            })

        services.sort(key=lambda s: (not s["available"], s["cost"] or 999))
        available_services = [s for s in services if s["available"]]

        countries_out.append({
            "code": iso or country_slug,
            "slug": country_slug,
            "name": name_en,
            "flag": _iso_to_flag(iso),
            "prefix": prefix,
            "services": services,
            "available": sum(s["count"] for s in available_services),
            "min_price": min((s["cost"] for s in available_services), default=None),
            "services_count": len(available_services),
        })

    countries_out.sort(key=lambda c: (-c["services_count"], c["name"]))

    return {
        "ok": True,
        "countries": countries_out,
        "error": None,
        "error_code": None,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }


# ══════════════════════════════════════════════════════════════
# 4) مولّدات الأكواد
# ══════════════════════════════════════════════════════════════
def _create_vouchers_batch(
    count: int,
    value: float,
    expires_days: int = 30,
    note: str = "",
    country: Optional[str] = None,
    service: Optional[str] = None,
    allowed_pairs: Optional[list[dict]] = None,
    batch_id: Optional[str] = None,
    label: str = "",
) -> list[dict]:
    """
    ينشئ دفعة أكواد.

    - allowed_pairs: قائمة [{"country":..., "service":...}, ...]
      كود واحد يصلح لأي من هذه الأزواج.
    - country/service: زوج واحد فقط (إن كانت allowed_pairs فارغة).
    - batch_id: اختياري — لتجميع عدة أكواد في دفعة واحدة.
    - label: اسم اختياري للكود/الدفعة (يظهر في التقارير).
    """
    prefix = os.getenv("VOUCHER_PREFIX", "JS").strip().upper()
    if not batch_id:
        batch_id = f"batch_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    now = datetime.now(timezone.utc)
    expires = now + timedelta(days=expires_days)

    pairs: list[dict] = []
    if allowed_pairs:
        for p in allowed_pairs:
            c = (p.get("country") or "").strip()
            s = (p.get("service") or "").strip()
            if c and s:
                pairs.append({"country": c, "service": s})
    if not pairs and country and service:
        pairs = [{"country": country, "service": service}]

    created: list[dict] = []
    for _ in range(count):
        while True:
            code = (
                f"{prefix}-{f'{value:g}'.replace('.', '')}"
                f"-{secrets.token_hex(2).upper()}"
                f"-{secrets.token_hex(2).upper()}"
            )
            if not any(v["code"] == code for v in STORE["vouchers"]):
                break

        single = pairs[0] if len(pairs) == 1 else None

        v = {
            "id": len(STORE["vouchers"]) + 1,
            "code": code,
            "value": float(value),
            "status": "unused",
            "batch_id": batch_id,
            "note": note,
            "label": label,
            "country": single["country"] if single else (country or None),
            "service": single["service"] if single else (service or None),
            "allowed_pairs": pairs,
            "created_at": now.isoformat(),
            "expires_at": expires.isoformat(),
            "used_by": None,
            "used_at": None,
            "used_on": None,
            "in_store": False,
            "sold_price_sar": None,
            "sold_at": None,
        }
        STORE["vouchers"].append(v)
        created.append(v)
    return created


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_pairs(v: dict) -> list[dict]:
    """يعيد قائمة الأزواج المسموحة لكود، مع التوافق العكسي."""
    pairs = v.get("allowed_pairs") or []
    if pairs:
        return pairs
    if v.get("country") and v.get("service"):
        return [{"country": v["country"], "service": v["service"]}]
    return []


# ══════════════════════════════════════════════════════════════
# 5) App
# ══════════════════════════════════════════════════════════════
app = FastAPI(title="Ramzon SMS — Admin Panel", version="3.0")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "rivalstore.xyz@gmail.com").strip().lower()
ADMIN_SECRET = os.getenv("ADMIN_SECRET", "").strip()


def _check_admin(request: Request) -> None:
    """كل واجهات الإدارة محمية برمز مستقل من Vercel Environment Variables."""
    if not ADMIN_SECRET:
        raise HTTPException(503, "ADMIN_SECRET غير مضبوط على الخادم")
    token = request.headers.get("X-Admin-Secret", "")
    if not secrets.compare_digest(token, ADMIN_SECRET):
        raise HTTPException(403, "غير مصرح بالدخول إلى الإدارة")


# ══════════════════════════════════════════════════════════════
# 6) Pydantic models
# ══════════════════════════════════════════════════════════════
class AdminLoginIn(BaseModel):
    email: str = ""
    password: str = ""


class AllowedPair(BaseModel):
    country: str = Field(..., min_length=1)
    service: str = Field(..., min_length=1)


class VoucherBatchCreate(BaseModel):
    count: int = Field(..., ge=1, le=1000)
    value: float = Field(..., ge=1)
    expires_days: int = Field(30, ge=1, le=365)
    note: str = ""
    label: str = ""
    country: str = ""
    service: str = ""
    allowed_pairs: list[AllowedPair] = Field(default_factory=list)


class VoucherPair(BaseModel):
    country: str
    service: str
    count: int = Field(..., ge=1, le=1000)


class VoucherMultiCreate(BaseModel):
    value: float = Field(..., ge=1)
    expires_days: int = Field(30, ge=1, le=365)
    note: str = ""
    label: str = ""
    pairs: list[VoucherPair] = Field(default_factory=list)
    merge: bool = False
    count: int = Field(1, ge=1, le=1000)
    allowed_pairs: list[AllowedPair] = Field(default_factory=list)


class VoucherGroup(BaseModel):
    """مجموعة أزواج تُولّد لها كود موحّد واحد."""
    label: str = ""
    pairs: list[AllowedPair] = Field(..., min_length=1)


class MatrixGenerateRequest(BaseModel):
    """
    التوليد المرن بثلاثة أوضاع:
      - merged:   كود واحد يصلح لكل الأزواج في pairs
      - groups:   كل مجموعة في groups → كود واحد
      - separate: كود منفصل لكل زوج في pairs
    """
    value: float = Field(..., ge=1)
    expires_days: int = Field(30, ge=1, le=365)
    note: str = ""
    label: str = ""
    mode: str = "merged"
    count: int = Field(1, ge=1, le=1000)
    pairs: list[AllowedPair] = Field(default_factory=list)
    groups: list[VoucherGroup] = Field(default_factory=list)


class VoucherCheckIn(BaseModel):
    code: str = Field(..., min_length=1)
    country: str = Field(..., min_length=1)
    service: str = Field(..., min_length=1)


class PopularServiceItem(BaseModel):
    country_slug: str
    service_id: str
    order: int = 0


class PopularServicesUpdate(BaseModel):
    items: list[PopularServiceItem] = Field(default_factory=list)


# ══════════════════════════════════════════════════════════════
# 7) Pages
# ══════════════════════════════════════════════════════════════
@app.get("/", response_class=HTMLResponse)
@app.get("/login", response_class=HTMLResponse)
@app.get("/admin-panel", response_class=HTMLResponse)
async def admin_panel(request: Request):
    return templates.TemplateResponse(request=request, name="admin.html", context={})


@app.get("/health")
async def health(request: Request):
    _check_admin(request)
    _refresh()
    _info = _store_file_info()
    merged_count = sum(
        1 for v in STORE["vouchers"]
        if len(_normalize_pairs(v)) > 1
    )
    used_count = sum(1 for v in STORE["vouchers"] if v.get("status") == "used")
    out = {
        "status": "ok",
        "app": "admin",
        "version": app.version,
        "auth": "protected",
        "store_file": _info["path"],
        "store_file_exists": _info["exists"],
        "store_kind": _info["kind"],
        "sim5_enabled": SIM5_ENABLED,
        "sim5_base": SIM5_BASE,
        "catalog_cached": _SIM5_CACHE["prices"]["data"] is not None,
        "counts": {
            "vouchers": len(STORE["vouchers"]),
            "merged_vouchers": merged_count,
            "used_vouchers": used_count,
            "customers": len(STORE["customers"]),
            "orders": len(STORE["orders"]),
            "popular_services": len(STORE.get("popular_services", [])),
        },
        "features": {
            "multi_pair_vouchers": True,
            "matrix_generate": True,
            "voucher_check_endpoint": True,
            "voucher_label": True,
            "used_vouchers_endpoint": True,
            "popular_services_admin": True,
            "blocked_countries": sorted(BLOCKED_COUNTRY_SLUGS),
            "blocked_country_codes": sorted(BLOCKED_COUNTRY_CODES),
            "access_codes": False,
        },
    }
    if _info.get("version") is not None:
        out["store_version"] = _info["version"]
    if _info.get("size_bytes") is not None:
        out["store_size_bytes"] = _info["size_bytes"]
    return out


# ══════════════════════════════════════════════════════════════
# 8) Auth (توافقي)
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/login")
async def admin_login(request: Request, payload: AdminLoginIn = None):
    _check_admin(request)
    return {"ok": True}


@app.get("/api/v1/admin/whoami")
async def admin_whoami(request: Request):
    _check_admin(request)
    return {"ok": True, "email": ADMIN_EMAIL, "auth": "protected"}


@app.post("/api/v1/admin/logout")
async def admin_logout(request: Request):
    _check_admin(request)
    return {"ok": True}


# ══════════════════════════════════════════════════════════════
# 8b) 5SIM Catalog
# ══════════════════════════════════════════════════════════════
@app.get("/api/v1/admin/catalog")
async def admin_catalog(request: Request, force: bool = False):
    _check_admin(request)
    result = await build_live_catalog(force=force)
    return {
        "ok": result["ok"],
        "source": "5sim",
        "markup_percent": FIVESIM_MARKUP_PERCENT,
        "fetched_at": result["fetched_at"],
        "error": result["error"],
        "error_code": result["error_code"],
        "countries": result["countries"],
        "blocked_countries": sorted(BLOCKED_COUNTRY_SLUGS),
    }


@app.get("/api/v1/admin/catalog/refresh")
async def admin_catalog_refresh(request: Request):
    _check_admin(request)
    result = await build_live_catalog(force=True)
    return {
        "ok": result["ok"],
        "source": "5sim",
        "markup_percent": FIVESIM_MARKUP_PERCENT,
        "fetched_at": result["fetched_at"],
        "error": result["error"],
        "error_code": result["error_code"],
        "countries": result["countries"],
        "blocked_countries": sorted(BLOCKED_COUNTRY_SLUGS),
    }


@app.get("/api/v1/admin/sim5-profile")
async def admin_sim5_profile(request: Request):
    _check_admin(request)
    if not SIM5_ENABLED:
        raise HTTPException(503, "5SIM غير مفعّل — SIM5_API_KEY غير مضبوط")
    try:
        p = await _sim5_get("/user/profile", auth=True)
    except Sim5Error as e:
        raise HTTPException(e.status or 503, e.message)
    return {
        "ok": True,
        "balance": p.get("balance"),
        "frozen_balance": p.get("frozen_balance"),
        "rating": p.get("rating"),
        "email": p.get("email"),
        "vendor": p.get("vendor"),
    }


# ══════════════════════════════════════════════════════════════
# 9) Wallet
# ══════════════════════════════════════════════════════════════
@app.get("/api/v1/admin/wallet")
async def admin_owner_wallet(request: Request):
    _check_admin(request)
    _refresh()
    settings = STORE.setdefault("admin_settings", {})
    fx = float(settings.get("usd_sar_rate", 3.95))
    try:
        profile = await _sim5_get("/user/profile", auth=True)
        real_balance = float(profile["balance"])
        frozen = float(profile.get("frozen_balance") or 0)
        warning = real_balance * fx <= float(settings.get("low_balance_threshold_sar", 10))
        return {"ok": True, "live": True, "balance_usd": real_balance,
                "balance_sar": round(real_balance * fx, 2),
                "frozen_balance_sar": round(frozen * fx, 2),
                "rate": fx, "low_balance": warning,
                "alert_threshold_sar": float(settings.get("low_balance_threshold_sar", 10)),
                "email_enabled": all(os.getenv(k) for k in ("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM")),
                "updated_at": _now_iso()}
    except (Sim5Error, KeyError, TypeError, ValueError):
        # لا نستبدل الرصيد الفعلي برصيد تقديري داخل المتجر.
        return {"ok": False, "live": False, "balance_sar": None,
                "message": "تعذّر جلب رصيد المورّد الحقيقي. أعد المحاولة."}


# ══════════════════════════════════════════════════════════════
# Ramzon admin settings, inventory publishing and verified sales
# ══════════════════════════════════════════════════════════════
class AdminSettingsUpdate(BaseModel):
    usd_sar_rate: float = Field(..., ge=0.01, le=100)
    low_balance_threshold_sar: float = Field(..., ge=0, le=100000)
    alert_email: str = Field("rivalstore.xyz@gmail.com", max_length=254)


class VoucherSale(BaseModel):
    sold_price_sar: float = Field(..., gt=0, le=100000)


class ListingPrice(BaseModel):
    listing_price_sar: float | None = Field(default=None, gt=0, le=100000)


@app.get("/api/v1/admin/settings")
async def get_admin_settings(request: Request):
    _check_admin(request)
    _refresh()
    cfg = STORE.get("admin_settings", {})
    return {"usd_sar_rate": cfg.get("usd_sar_rate", 3.95),
            "low_balance_threshold_sar": cfg.get("low_balance_threshold_sar", 10),
            "alert_email": cfg.get("alert_email", "rivalstore.xyz@gmail.com"),
            "buy_url": "https://ramzon-sms.vercel.app/buy"}


@app.put("/api/v1/admin/settings")
async def put_admin_settings(payload: AdminSettingsUpdate, request: Request):
    _check_admin(request)
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", payload.alert_email.strip()):
        raise HTTPException(400, "صيغة البريد الإلكتروني غير صحيحة")
    _refresh()
    cfg = STORE.setdefault("admin_settings", {})
    cfg.update(payload.model_dump())
    _persist_now()
    return {"ok": True, **cfg}


@app.post("/api/v1/admin/vouchers/batch/{batch_id}/listed")
async def mark_batch_listed(batch_id: str, request: Request, payload: ListingPrice | None = None):
    _check_admin(request)
    _refresh()
    matches = [v for v in STORE["vouchers"] if v.get("batch_id") == batch_id]
    if not matches:
        raise HTTPException(404, "الدفعة غير موجودة")
    for v in matches:
        v["in_store"] = True
        v["listed_at"] = _now_iso()
        if payload and payload.listing_price_sar is not None:
            v["listing_price_sar"] = round(payload.listing_price_sar, 2)
    _persist_now()
    return {"ok": True, "count": len(matches), "batch_id": batch_id}


@app.post("/api/v1/admin/vouchers/{voucher_id}/listed")
async def mark_voucher_listed(voucher_id: int, request: Request, payload: ListingPrice | None = None):
    _check_admin(request)
    _refresh()
    v = next((v for v in STORE["vouchers"] if v["id"] == voucher_id), None)
    if not v:
        raise HTTPException(404, "الكود غير موجود")
    v["in_store"] = True
    v["listed_at"] = _now_iso()
    if payload and payload.listing_price_sar is not None:
        v["listing_price_sar"] = round(payload.listing_price_sar, 2)
    _persist_now()
    return {"ok": True}


@app.post("/api/v1/admin/vouchers/{voucher_id}/sale")
async def confirm_voucher_sale(voucher_id: int, payload: VoucherSale, request: Request):
    """الإيراد يحسب من سعر البيع المؤكّد يدويًا، لا قيمة الكوبون الاسمية."""
    _check_admin(request)
    _refresh()
    v = next((v for v in STORE["vouchers"] if v["id"] == voucher_id), None)
    if not v:
        raise HTTPException(404, "الكود غير موجود")
    if v.get("sold_at"):
        raise HTTPException(409, "سبق تأكيد بيع هذا الكود؛ لن نسجل إيرادًا مكررًا")
    v["sold_at"] = _now_iso()
    v["sold_price_sar"] = round(payload.sold_price_sar, 2)
    v["sale_source"] = "manual_confirmation"
    v["in_store"] = True
    _persist_now()
    return {"ok": True, "sold_price_sar": v["sold_price_sar"]}


@app.get("/api/v1/admin/analytics")
async def admin_analytics(request: Request, month: str = ""):
    _check_admin(request)
    _refresh()
    if month and not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month):
        raise HTTPException(400, "الشهر يجب أن يكون YYYY-MM")
    cfg = STORE.get("admin_settings", {})
    fx = float(cfg.get("usd_sar_rate", 3.95))
    current = month or datetime.now(timezone.utc).strftime("%Y-%m")
    sold = [v for v in STORE["vouchers"] if (v.get("sold_at") or "")[:7] == current and v.get("sold_price_sar") is not None]
    # يحسب فقط الطلب الذي استلم SMS فعلًا أو انتهى بنجاح ولم يُسترد.
    cost_orders = [o for o in STORE["orders"] if (o.get("created_at") or "")[:7] == current
                   and (o.get("sms") or o.get("status") == "FINISHED") and not o.get("refunded")]
    revenue_sar = round(sum(float(v["sold_price_sar"]) for v in sold), 2)
    cost_sar = round(sum(float(o.get("fivesim_cost", 0)) * fx for o in cost_orders), 2)
    return {"ok": True, "month": current, "rate": fx,
            "confirmed_sales_count": len(sold), "confirmed_sales_sar": revenue_sar,
            "supplier_consumed_orders": len(cost_orders), "supplier_cost_sar": cost_sar,
            "estimated_profit_sar": round(revenue_sar - cost_sar, 2),
            "unverified_sales_count": sum(1 for v in STORE["vouchers"] if v.get("status") == "used" and not v.get("sold_at")),
            "disclaimer": "الإيرادات من المبيعات المؤكدة يدويًا، ولا يوجد ربط مبيعات مباشر بسلة. الربح قبل الرسوم والضرائب وقد تختلف تواريخ البيع عن تواريخ التكلفة."}


# ══════════════════════════════════════════════════════════════
# 10) Vouchers — list
# ══════════════════════════════════════════════════════════════
@app.get("/api/v1/admin/vouchers")
async def admin_list_vouchers(
    request: Request,
    status_filter: Optional[str] = None,
    batch_id: Optional[str] = None,
):
    _check_admin(request)
    _refresh()

    vouchers = STORE["vouchers"]
    now = datetime.now(timezone.utc)
    changed = False
    for v in vouchers:
        if v.get("status") == "unused":
            try:
                exp = datetime.fromisoformat(v["expires_at"])
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if now > exp:
                    v["status"] = "expired"
                    changed = True
            except (ValueError, KeyError, TypeError):
                pass
    if changed:
        _persist()

    filtered = vouchers
    if status_filter:
        filtered = [v for v in filtered if v["status"] == status_filter]
    if batch_id:
        filtered = [v for v in filtered if v.get("batch_id") == batch_id]

    summary = {
        "total": len(vouchers),
        "unused": sum(1 for v in vouchers if v["status"] == "unused"),
        "used": sum(1 for v in vouchers if v["status"] == "used"),
        "reserved": sum(1 for v in vouchers if v["status"] == "reserved"),
        "listed": sum(1 for v in vouchers if v.get("in_store")),
        "sold": sum(1 for v in vouchers if v.get("sold_at")),
        "expired": sum(1 for v in vouchers if v["status"] == "expired"),
        "disabled": sum(1 for v in vouchers if v["status"] == "disabled"),
        "total_value_unused": round(
            sum(v["value"] for v in vouchers if v["status"] == "unused"), 2
        ),
        "total_value_used": round(
            sum(v["value"] for v in vouchers if v["status"] == "used"), 2
        ),
        "merged": sum(1 for v in vouchers if len(_normalize_pairs(v)) > 1),
        "verified_sales_sar": round(sum(float(v.get("sold_price_sar") or 0) for v in vouchers if v.get("sold_at")), 2),
        # Expected shelf value of unused codes; this is NOT revenue.
        "listed_unused_price_sar": round(sum(float(v.get("listing_price_sar") or 0)
            for v in vouchers if v.get("status") == "unused" and v.get("in_store")), 2),
        "missing_listing_price_count": sum(1 for v in vouchers
            if v.get("status") == "unused" and v.get("in_store") and v.get("listing_price_sar") is None),
    }

    out = []
    for v in filtered:
        pairs = _normalize_pairs(v)
        out.append({
            **v,
            "label": v.get("label") or "",
            "country": v.get("country") or (pairs[0]["country"] if len(pairs) == 1 else None),
            "service": v.get("service") or (pairs[0]["service"] if len(pairs) == 1 else None),
            "allowed_pairs": pairs,
            "is_merged": len(pairs) > 1,
        })

    return {"summary": summary, "vouchers": out}


# ══════════════════════════════════════════════════════════════
# ✨ الأكواد المستخدمة
# ══════════════════════════════════════════════════════════════
@app.get("/api/v1/admin/vouchers/used")
async def admin_list_used_vouchers(request: Request):
    _check_admin(request)
    _refresh()

    used = [v for v in STORE["vouchers"] if v.get("status") == "used"]
    used_sorted = sorted(used, key=lambda v: v.get("used_at") or "", reverse=True)

    total_value = sum(float(v.get("sold_price_sar") or 0) for v in used if v.get("sold_at"))

    out = []
    for v in used_sorted[:500]:
        pairs = _normalize_pairs(v)
        used_on = v.get("used_on") or {}
        out.append({
            "id": v["id"],
            "code": v["code"],
            "value": float(v.get("value", 0)),
            "sold_price_sar": v.get("sold_price_sar"),
            "label": v.get("label") or "",
            "note": v.get("note") or "",
            "batch_id": v.get("batch_id"),
            "status": v.get("status"),
            "created_at": v.get("created_at"),
            "expires_at": v.get("expires_at"),
            "used_at": v.get("used_at"),
            "used_by": v.get("used_by"),
            "used_on": used_on,
            "allowed_pairs": pairs,
            "is_merged": len(pairs) > 1,
        })

    return {
        "summary": {
            "total_used": len(used),
            "total_value": round(total_value, 2),
            "unverified_sales": sum(1 for v in used if not v.get("sold_at")),
        },
        "vouchers": out,
    }


# ══════════════════════════════════════════════════════════════
# 11) Vouchers — generate (دفعة واحدة، مع دعم allowed_pairs)
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/vouchers/generate")
async def admin_generate_vouchers(payload: VoucherBatchCreate, request: Request):
    _check_admin(request)
    _refresh()

    created = _create_vouchers_batch(
        count=payload.count,
        value=payload.value,
        expires_days=payload.expires_days,
        note=payload.note,
        label=payload.label,
        country=payload.country or None,
        service=payload.service or None,
        allowed_pairs=[p.model_dump() for p in payload.allowed_pairs] or None,
    )
    _persist_now()
    pairs_out = _normalize_pairs(created[0]) if created else []
    return {
        "ok": True,
        "count": len(created),
        "batch_id": created[0]["batch_id"] if created else None,
        "total_value": round(sum(v["value"] for v in created), 2),
        "codes": [v["code"] for v in created],
        "country": payload.country or None,
        "service": payload.service or None,
        "label": payload.label,
        "allowed_pairs": pairs_out,
        "is_merged": len(pairs_out) > 1,
    }


# ══════════════════════════════════════════════════════════════
# 12) Vouchers — generate multi
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/vouchers/generate-multi")
async def admin_generate_vouchers_multi(payload: VoucherMultiCreate, request: Request):
    """
    يدعم وضعين:
    - merge=False: كود منفصل لكل زوج في pairs.
    - merge=True: كود واحد (× count) يصلح لأي من allowed_pairs.
    """
    _check_admin(request)
    _refresh()

    # ── وضع الدمج ──
    if payload.merge:
        if not payload.allowed_pairs:
            raise HTTPException(400, "allowed_pairs مطلوبة في وضع الدمج")
        if not payload.count or payload.count < 1:
            raise HTTPException(400, "count مطلوبة في وضع الدمج (≥1)")

        created = _create_vouchers_batch(
            count=payload.count,
            value=payload.value,
            expires_days=payload.expires_days,
            note=payload.note,
            label=payload.label,
            allowed_pairs=[p.model_dump() for p in payload.allowed_pairs],
        )
        _persist_now()

        pairs_desc = ", ".join(f"{p.country}/{p.service}" for p in payload.allowed_pairs)
        return {
            "ok": True,
            "merge": True,
            "total_count": len(created),
            "total_value": round(sum(v["value"] for v in created), 2),
            "batches": [{
                "country": "merged",
                "service": pairs_desc,
                "label": payload.label,
                "allowed_pairs": [p.model_dump() for p in payload.allowed_pairs],
                "count": len(created),
                "batch_id": created[0]["batch_id"] if created else None,
                "codes": [v["code"] for v in created],
                "total_value": round(sum(v["value"] for v in created), 2),
            }],
        }

    # ── الوضع القديم ──
    if not payload.pairs:
        raise HTTPException(400, "pairs مطلوبة (أو استخدم merge=true مع allowed_pairs)")

    all_created: list[dict] = []
    batches: list[dict] = []
    for p in payload.pairs:
        created = _create_vouchers_batch(
            count=p.count,
            value=payload.value,
            expires_days=payload.expires_days,
            note=payload.note,
            label=payload.label,
            country=p.country,
            service=p.service,
        )
        all_created.extend(created)
        batches.append({
            "country": p.country,
            "service": p.service,
            "label": payload.label,
            "count": len(created),
            "batch_id": created[0]["batch_id"] if created else None,
            "codes": [v["code"] for v in created],
            "total_value": round(sum(v["value"] for v in created), 2),
        })
    _persist_now()
    return {
        "ok": True,
        "merge": False,
        "total_count": len(all_created),
        "total_value": round(sum(v["value"] for v in all_created), 2),
        "batches": batches,
    }


# ══════════════════════════════════════════════════════════════
# 12b) Vouchers — generate matrix
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/vouchers/generate-matrix")
async def admin_generate_vouchers_matrix(
    payload: MatrixGenerateRequest,
    request: Request,
):
    """
    توليد مرن بثلاثة أوضاع:

    - mode="merged":
        كل الأزواج في pairs → كود واحد لكل count.
    - mode="groups":
        كل مجموعة → كود موحّد × count.
    - mode="separate":
        كود منفصل لكل زوج × count.
    """
    _check_admin(request)
    _refresh()

    mode = (payload.mode or "merged").lower()
    created_all: list[dict] = []
    response_batches: list[dict] = []

    master_batch_id = f"matrix_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

    # ══ merged ══
    if mode == "merged":
        if not payload.pairs:
            raise HTTPException(400, "pairs مطلوبة في وضع merged")

        pairs_dict = [p.model_dump() for p in payload.pairs]
        created = _create_vouchers_batch(
            count=payload.count,
            value=payload.value,
            expires_days=payload.expires_days,
            note=payload.note,
            label=payload.label,
            allowed_pairs=pairs_dict,
            batch_id=f"{master_batch_id}_merged",
        )
        _persist_now()
        created_all.extend(created)

        pairs_desc = ", ".join(f"{p['country']}/{p['service']}" for p in pairs_dict)
        response_batches.append({
            "mode": "merged",
            "label": payload.label or f"كود موحّد ({len(pairs_dict)} زوج)",
            "country": "merged",
            "service": pairs_desc,
            "allowed_pairs": pairs_dict,
            "count": len(created),
            "batch_id": created[0]["batch_id"] if created else None,
            "codes": [v["code"] for v in created],
            "total_value": round(sum(v["value"] for v in created), 2),
        })

    # ══ groups ══
    elif mode == "groups":
        if not payload.groups:
            raise HTTPException(400, "groups مطلوبة في وضع groups")

        for g_idx, group in enumerate(payload.groups):
            pairs_dict = [p.model_dump() for p in group.pairs]
            if not pairs_dict:
                continue

            group_label = group.label or payload.label or f"مجموعة {g_idx + 1}"

            created = _create_vouchers_batch(
                count=payload.count,
                value=payload.value,
                expires_days=payload.expires_days,
                note=payload.note,
                label=group_label,
                allowed_pairs=pairs_dict,
                batch_id=f"{master_batch_id}_g{g_idx + 1}",
            )
            _persist_now()
            created_all.extend(created)

            pairs_desc = ", ".join(f"{p['country']}/{p['service']}" for p in pairs_dict)
            response_batches.append({
                "mode": "groups",
                "label": group_label,
                "country": "group",
                "service": pairs_desc,
                "allowed_pairs": pairs_dict,
                "count": len(created),
                "batch_id": created[0]["batch_id"] if created else None,
                "codes": [v["code"] for v in created],
                "total_value": round(sum(v["value"] for v in created), 2),
            })

    # ══ separate ══
    elif mode == "separate":
        if not payload.pairs:
            raise HTTPException(400, "pairs مطلوبة في وضع separate")

        for p_idx, p in enumerate(payload.pairs):
            created = _create_vouchers_batch(
                count=payload.count,
                value=payload.value,
                expires_days=payload.expires_days,
                note=payload.note,
                label=payload.label,
                country=p.country,
                service=p.service,
                batch_id=f"{master_batch_id}_p{p_idx + 1}",
            )
            _persist_now()
            created_all.extend(created)

            response_batches.append({
                "mode": "separate",
                "label": payload.label or f"{p.country}/{p.service}",
                "country": p.country,
                "service": p.service,
                "allowed_pairs": [p.model_dump()],
                "count": len(created),
                "batch_id": created[0]["batch_id"] if created else None,
                "codes": [v["code"] for v in created],
                "total_value": round(sum(v["value"] for v in created), 2),
            })
    else:
        raise HTTPException(
            400,
            f"mode غير مدعوم: {mode}. استخدم merged/groups/separate",
        )

    return {
        "ok": True,
        "mode": mode,
        "master_batch_id": master_batch_id,
        "label": payload.label,
        "total_count": len(created_all),
        "total_value": round(sum(v["value"] for v in created_all), 2),
        "batches": response_batches,
    }


# ══════════════════════════════════════════════════════════════
# 12c) Vouchers — check (تحقق مسبق)
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/vouchers/check")
async def admin_check_voucher(payload: VoucherCheckIn, request: Request):
    """
    يتحقق أن الكود:
      - موجود
      - غير مستخدم/معطّل
      - غير منتهي
      - يصلح للزوج (country, service) المطلوب

    لا يستهلك الكود — آمن للاستدعاء من واجهة الزبون.
    """
    _check_admin(request)
    _refresh()

    v = next((x for x in STORE["vouchers"] if x["code"] == payload.code), None)
    if not v:
        raise HTTPException(404, "الكود غير موجود")

    if v["status"] != "unused":
        status_ar = {
            "used": "مستخدم",
            "expired": "منتهي",
            "disabled": "معطّل",
        }.get(v["status"], v["status"])
        raise HTTPException(400, f"هذا الكود {status_ar} — لا يمكن استخدامه")

    try:
        exp = datetime.fromisoformat(v["expires_at"])
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > exp:
            v["status"] = "expired"
            _persist()
            raise HTTPException(400, "هذا الكود منتهي الصلاحية")
    except (ValueError, KeyError, TypeError):
        pass

    pairs = _normalize_pairs(v)
    if pairs:
        ok = any(
            p["country"] == payload.country and p["service"] == payload.service
            for p in pairs
        )
        if not ok:
            pairs_str = ", ".join(f"{p['country']}/{p['service']}" for p in pairs)
            raise HTTPException(
                403,
                f"هذا الكود لا يصلح لـ {payload.country}/{payload.service}. "
                f"يصلح لـ: {pairs_str}",
            )

    return {
        "ok": True,
        "code": v["code"],
        "value": v["value"],
        "label": v.get("label") or "",
        "expires_at": v["expires_at"],
        "allowed_pairs": pairs,
        "is_merged": len(pairs) > 1,
        "note": v.get("note", ""),
        "selected_pair": {
            "country": payload.country,
            "service": payload.service,
        },
    }


# ══════════════════════════════════════════════════════════════
# 13) Vouchers — disable
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/vouchers/{voucher_id}/disable")
async def admin_disable_voucher(voucher_id: int, request: Request):
    _check_admin(request)
    _refresh()
    v = next((v for v in STORE["vouchers"] if v["id"] == voucher_id), None)
    if not v:
        raise HTTPException(404, "الكود غير موجود")
    if v["status"] == "used":
        raise HTTPException(400, "لا يمكن تعطيل كود مستخدم")
    v["status"] = "disabled"
    _persist_now()
    return {"ok": True, "status": "disabled"}


# ══════════════════════════════════════════════════════════════
# ✨ Popular Services (admin)
# ══════════════════════════════════════════════════════════════
@app.get("/api/v1/admin/popular")
async def admin_list_popular(request: Request):
    _check_admin(request)
    _refresh()
    return {"ok": True, "popular": STORE.get("popular_services", [])}


@app.put("/api/v1/admin/popular")
async def admin_set_popular(payload: PopularServicesUpdate, request: Request):
    _check_admin(request)
    _refresh()
    items = []
    for it in payload.items:
        c = it.country_slug.strip().lower()
        s = it.service_id.strip().lower()
        if not c or not s:
            continue
        # ✨ منع إضافة دول محظورة إلى "الأكثر طلباً"
        if _is_country_blocked(c):
            print(f"[admin_set_popular] 🚫 رفض '{c}/{s}' — دولة محظورة")
            continue
        items.append({
            "country_slug": c,
            "service_id": s,
            "order": int(it.order),
        })
    items.sort(key=lambda x: x["order"])
    STORE["popular_services"] = items
    _persist_now()
    return {"ok": True, "count": len(items), "popular": items}


@app.delete("/api/v1/admin/popular")
async def admin_clear_popular(request: Request):
    _check_admin(request)
    _refresh()
    STORE["popular_services"] = []
    _persist_now()
    return {"ok": True, "count": 0}


# ══════════════════════════════════════════════════════════════
# 16) Backup
# ══════════════════════════════════════════════════════════════
@app.post("/api/v1/admin/backup")
async def admin_backup(request: Request):
    _check_admin(request)
    _refresh()
    result = backup(STORE)
    save_now(STORE)

    if isinstance(result, Path):
        try:
            size = result.stat().st_size
        except OSError:
            size = None
        return {
            "ok": True,
            "path": str(result),
            "size": size,
            "kind": "file",
        }
    if isinstance(result, dict):
        return {"ok": True, **result}
    if result is None:
        return {
            "ok": True,
            "path": None,
            "kind": "none",
            "note": "backup غير مدعوم في وضع PostgreSQL — استخدم pg_dump",
        }
    return {"ok": True, "path": str(result), "kind": "string"}


# ══════════════════════════════════════════════════════════════
# 17) Error handler
# ══════════════════════════════════════════════════════════════
@app.exception_handler(HTTPException)
async def http_exc_handler(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


# ══════════════════════════════════════════════════════════════
# 18) Startup / Shutdown
# ══════════════════════════════════════════════════════════════
@app.on_event("startup")
async def _startup_log():
    _refresh()
    _info = _store_file_info()
    merged_count = sum(1 for v in STORE["vouchers"] if len(_normalize_pairs(v)) > 1)
    used_count = sum(1 for v in STORE["vouchers"] if v.get("status") == "used")
    print("═" * 60)
    print(f"[admin] 🚀 لوحة الأدمن v{app.version}  (🔒 رمز إدارة مطلوب)")
    print(f"[admin] root          = {ADMIN_DIR}")
    print(f"[admin] project root  = {PROJECT_ROOT}")
    print(f"[admin] store file    = {_info['path']}")
    print(f"[admin] store kind    = {_info['kind']}")
    print(f"[admin] store ready   = {'✅' if _info['exists'] else '❌'}")
    if _info.get("version") is not None:
        print(f"[admin] store version = {_info['version']}")
    if _info.get("size_bytes") is not None:
        print(f"[admin] store size    = {_info['size_bytes']} bytes")
    print(f"[admin] store_status  = {'✅' if _HAS_STORE_STATUS else '⚠️  fallback'}")
    print(f"[admin] templates     = {TEMPLATES_DIR}")
    print(f"[admin] admin.html    = {'✅' if (TEMPLATES_DIR / 'admin.html').exists() else '❌ مفقود'}")
    print(f"[admin] static        = {STATIC_DIR} (exists={STATIC_DIR.exists()})")
    print(f"[admin] SIM5          = {SIM5_ENABLED}")
    print(f"[admin] SIM5 base     = {SIM5_BASE}")
    print(f"[admin] MARKUP        = {FIVESIM_MARKUP_PERCENT}%")
    print(f"[admin] CATALOG TTL   = {CATALOG_TTL_SECONDS}s")
    print(f"[admin] BLOCKED slugs = {sorted(BLOCKED_COUNTRY_SLUGS) or '—'}")
    print(f"[admin] BLOCKED codes = {sorted(BLOCKED_COUNTRY_CODES) or '—'}")
    print(f"[admin] features      = multi_pair ✅ | matrix ✅ | check ✅ | label ✅ | used ✅ | block ✅")
    print(f"[admin] owner_wallet  = {STORE['owner_wallet']}")
    print(f"[admin] vouchers      = {len(STORE['vouchers'])}  (merged: {merged_count}, used: {used_count})")
    print(f"[admin] customers     = {len(STORE['customers'])}")
    print(f"[admin] orders        = {len(STORE['orders'])}")
    print(f"[admin] popular       = {len(STORE.get('popular_services', []))}")
    if SIM5_ENABLED:
        try:
            profile = await _sim5_get("/user/profile", auth=True)
            print(f"[admin] 5SIM balance  = {profile.get('balance')}")
            print(f"[admin] 5SIM rating   = {profile.get('rating')}")
        except Sim5Error as e:
            print(f"[admin] ⚠️ 5SIM profile: [{e.status}] {e.message}")
    print("═" * 60)


@app.on_event("shutdown")
async def _shutdown_save():
    try:
        save_now(STORE)
        result = backup(STORE)
        if isinstance(result, Path):
            print(f"[admin] 💾 تم حفظ store ونسخ احتياطي في {result}")
        elif result is None:
            print("[admin] 💾 تم حفظ store (بدون نسخ احتياطي في وضع PG)")
        else:
            print(f"[admin] 💾 تم حفظ store ونسخ احتياطي: {result}")
    except Exception as e:
        print(f"[admin] ⚠️  فشل الحفظ عند الإغلاق: {type(e).__name__}: {e}")
